#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
ll m,n,a[2000005],sum,ans;
int main(void){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cin >> n >> m;
	for(int i = 0;i < n;++ i)
		cin >> a[i];
	sort(a,a+n);
	a[n] = m;
	if(a[0] > 1){
		cout << "No answer!!!";
		return 0;
	}
	for(int i = 1;i <= n;++ i){
		if(sum < a[i]-1){
			ll c = (a[i]-sum-2) / a[i-1] + 1;
			ans += c;
			sum += 1ll * c * a[i-1];
		}
		if(sum >= m){
			-- ans;
			break;
		}
	}
	cout << ans + 1;
	return 0;
}
