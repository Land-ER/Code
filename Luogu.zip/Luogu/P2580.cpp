#include<cstdio>
#define MAXN_ 500005
#define re_ register
int next[MAXN_][26];
char letter[MAXN_];
int check[MAXN_];
char inp[55];
int n,m;
int pt,cnt = 1;
void solve(void){
	re_ int i,j;
	scanf("%d",&n);
	for(i = 0;i < n;++ i){
		scanf("%s",inp);
		pt = 0;
		for(j = 0;inp[j] != '\0';++ j){
			if(next[pt][inp[j]-'a'] == 0){
				next[pt][inp[j]-'a'] = cnt;
				letter[cnt] = inp[j];
				++ cnt;
			}
			pt = next[pt][inp[j]-'a'];
		}
		check[pt] = 1;
	}
	scanf("%d",&m);
	bool flag;
	for(i = 0;i < m;++ i){
		scanf("%s",inp);
		flag = 0;
		pt = 0;
		for(j = 0;inp[j] != '\0';++ j){
			if(next[pt][inp[j]-'a'] == 0){
				printf("WRONG\n");
				flag = 1;
				break;
			}
			pt = next[pt][inp[j]-'a'];
		}
		if(flag)
			continue;
		if(check[pt] == 0)
			printf("WRONG\n");
		else if(check[pt] == 2)
			printf("REPEAT\n");
		else{
			check[pt] = 2;
			printf("OK\n");
		}
	}
	return;
}
int main(void){
	solve();
	return 0;
}
/*
#include<iostream>
#include<string>
#include<map>
using namespace std;
map<string,bool> list;
map<string,bool>::iterator pt;
void input(void){
	int n;
	string str;
	cin >> n;
	for(int i = 0;i < n;++ i){
		cin >> str;
		list.insert(make_pair(str,0));
	}
	return;
}
void solve(void){
	int n;
	string str;
	cin >> n;
	for(int i = 0;i < n;++ i){
		cin >> str;
		pt = list.find(str);
		if(pt == list.end())
			cout << "WRONG\n";
		else if((*pt).second)
			cout << "REPEAT\n";
		else{
			cout << "OK\n";
			(*pt).second = 1;
		}
	}
	return;
}
int main(void){
	input();
	solve();
	return 0;
}
*/
