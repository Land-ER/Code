#include<iostream>
using namespace std;

long long int dp[23];
const int list1[9]={0,2,1,-1,-2,-2,-1,1,2},list2[9]={0,1,2,2,1,-1,-2,-2,-1};
bool mark[23][23];
int n,m,x,y;

int main(void){
    int i,j,a,b;
    cin >> n >> m >> x >> y;
/*
    for(i = 0;i < 21;++ i)
        for(j = 0;j < 21;++ j)
            mark[i][j] = false;

    for(i = 0;i < 21;++ i)
        dp[i] = 1;

    for(i = 0;i < 9;++ i)
    {
        a = x+list1[i];
        b = y+list2[i];
        //mark[a][b] = (a>=0 && a<=n && b>=0 && b<=m);
        if(a>=0 && a<=n && b>=0 && b<=m)
        	mark[a][b] = true;
    }

    for(i = 0;i <= n;i ++) if(mark[0][i]) dp[i] = 0;

    for(i = 1;i <= n;++ i)
    {
        for(j = 0;j <= m;++ j)
        {
            if(mark[i][j]) dp[j] = 0;
            else if(j > 0) dp[j] += dp[j-1];
        }
    }
    cout << dp[m];
    return 0;
*/
    x += 2;
    y += 2;
    m += 2;
    n += 2;
    dp[2] = 1;
    for(i = 0;i < 9;++ i){
    	a = x+list1[i];
    	b = y+list2[i];
    	mark[a][b] = true;
	}
	for(i = 2;i <= n;++ i)
		for(j = 2;j <= m;++ j){
			if(mark[i][j])
				dp[j] = 0;
			else
				dp[j] += dp[j-1];
		}
	cout << dp[m];
	return 0;
}
