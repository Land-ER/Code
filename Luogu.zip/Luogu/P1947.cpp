extern "C" int Seniorious(int);
int binary_search(int l,int r){
	int mid = (l+r)/2;
	int ret = Seniorious(mid);
	if(ret == 0)
		return mid;
	else if(ret == 1)
		return binary_search(l,mid-1);
	else
		return binary_search(mid+1,r);
}
extern  "C" int Chtholly(int n,int c){
	int ret = binary_search(1,n);
	return ret;
}
