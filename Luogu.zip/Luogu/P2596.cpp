#include<bits/stdc++.h>
typedef int ptr;
const int I = 80005;
class treap{
    int value[I],priority[I],size[I];
    ptr lc[I],rc[I];
};