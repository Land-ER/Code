#include<iostream>
#include<algorithm>
using namespace std;
int h[1000005],n,op,k,s = 1;
void up(int x){
	while(x>1 && h[x]<h[x>>1]){
		swap(h[x],h[x>>1]);
		x >>= 1;
	}
	return;
}
void down(int x){
	static int t;
	while(x<<2 < s){
		t = h[x<<2]<h[(x<<2)+1] ? x<<2 : (x<<2)+1;
		if(h[x] < h[t])
			break;
		swap(h[x],h[t]);
		x = t;
	}
	return;
}
void solve(void){
	int x;
	scanf("%d",&n);
	while(n --){
		scanf("%d",&op);
		if(op == 1){
			scanf("%d",&x);
			h[s] = x;
			++ s;
			up(s-1);
		}
		else if(op == 2)
			printf("%d\n",h[1]);
		else{
			swap(h[1],h[s-1]);
			-- s;
			down(1);
		}
	}
	return;
}
int main(void){
	solve();
	return 0;
}
