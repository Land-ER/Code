#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
#define ll_ long long
struct edge{
	int v,w;
};
queue<int> q;
vector<edge> graph[10005];
int dis[10005],vis[10005];
int n,m,s;
void input(void){
	int a;
	edge p;
	scanf("%d%d%d",&n,&m,&s);
	for(int i = 0;i < m;++ i){
		scanf("%d%d%d",&a,&p.v,&p.w);
		graph[a].push_back(p);
	}
	return;
}
bool spfa(void){
	for(int i = 0;i < 10005;++ i)
		dis[i] = 2147483647;
	int p;
	dis[s] = 0;
	q.push(s);
	while(!q.empty()){
		p = q.front();
		q.pop();
		if(vis[p] == n)
			return 0;
		register int t = graph[p].end() - graph[p].begin();
		for(register int i = 0;i < t;++ i){
			if(dis[p]+graph[p][i].w < dis[graph[p][i].v]){
				dis[graph[p][i].v] = dis[p] + graph[p][i].w;
				++ vis[graph[p][i].v];
				q.push(graph[p][i].v);
			}
		}
	}
	return 1;
}
void output(void){
	for(int i = 1;i <= n;++ i)
		printf("%d ",dis[i]);
	return;
}
int main(void){
	input();
	spfa();
	output();
	return 0;
}
