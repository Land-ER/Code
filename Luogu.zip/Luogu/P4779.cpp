#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<algorithm>
#include<functional>
using namespace std;
struct edge{
	int v,w;
};
bool operator<(const edge& a,const edge &b){
	return a.w > b.w;
}
inline int min(int a,int b){
	return a<b ? a : b;
}
vector<edge> graph[100005];
priority_queue<edge> q;
int dis[100005];
bool col[100005];
int n,m,s;
void input(void){
	edge p;
	int k;
	scanf("%d%d%d",&n,&m,&s);
	for(int i = 0;i < m;++ i){
		scanf("%d%d%d",&k,&p.v,&p.w);
		graph[k].push_back(p);
	}
	return;
}
void dijkstra(void){
	edge p,l;
	vector<edge>::iterator pt;
	memset(dis,0x3f,sizeof(dis));
	dis[s] = 0;
	p.v = s;
	p.w = 0;
	q.push(p);
	while(!q.empty()){
		p = q.top();
		q.pop();
		col[p.v] = 1;
		if(p.w != dis[p.v])
			continue;
		for(pt = graph[p.v].begin();pt < graph[p.v].end();++ pt){
			if(!col[(*pt).v]){
				dis[(*pt).v] = min(dis[(*pt).v],dis[p.v]+(*pt).w);
				l.v = (*pt).v;
				l.w = dis[(*pt).v];
				q.push(l);
			}
		}
	}
	return;
}
void output(void){
	for(int i = 1;i <= n;++ i)
		printf("%d ",dis[i]);
	return;
}
int main(void){
	input();
	dijkstra();
	output();
	return 0;
}
