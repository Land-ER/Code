#include<bits/stdc++.h>
int main(void){
    int k,m,n;
    int w[205],v[205],dp[5005][55],p[55],sum;
    memset(dp,~0x3f,sizeof(dp));
    scanf("%d%d%d",&k,&m,&n);
    int a,b,c;
    for(int i = 1;i <= n;++ i)
        scanf("%d%d",&w[i],&v[i]);
    dp[0][1] = 0;
    for(int i = 1;i <= n;++ i){
        for(int j = m;j-w[i] >= 0;-- j){
            a = b = c = 1;
            for(int t = 1;t <= k;++ t)
                p[t] = dp[j][t];
            for( ;c <= k;++ c){
                if(dp[j-w[i]][a] + v[i] >= p[b]){
                    dp[j][c] = dp[j-w[i]][a] + v[i];
                    ++ a;
                }else if(dp[j-w[i]][a] + v[i] < p[b]){
                    dp[j][c] = p[b];
                    ++ b;
                }
            }
        }
    }
    sum = 0;
    for(int i = 1;i <= k;++ i)
        sum += dp[m][i];
    printf("%d",sum);
    return 0;
}