#include<iostream>
using namespace std;
inline long long int half(long long int a,long long int b){
	return 1ll*(a+b)/2;
}
void binary_search(long long int l,long long int r){
	long long int number;
	int ret;
	number = half(l,r);
	cout << number << endl;
	cin >> ret;
	if(!ret)
		return;
	else if(ret == 1){
		binary_search(l,number-1);
		return;
	}
	else{
		binary_search(number+1,r);
		return;
	}
}
int main(void){
	binary_search(1,1e9);
	return 0;
}
