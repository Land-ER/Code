#include<iostream>
using namespace std;
#define ll_ long long
#define maxn_ 100005
ll_ int a[maxn_],d[maxn_<<4],lz[maxn_<<4];
int n,m,x,y,k;
inline int child(int id){
	return (id<<1) + 1;
}
inline int mid(int l,int r){
	return ((r-l)>>1) + l;
}
void input(void){
	cin >> n >> m;
	for(register int i = 1;i <= n;++ i)
		cin >> a[i];
	return;
}
void build(int id,int l,int r){
	if(l == r)
		d[id] = a[l];
	else{
		build(child(id),l,mid(l,r));
		build(child(id)+1,mid(l,r)+1,r);
		d[id] = d[child(id)] + d[child(id)+1];
	}
	return;
}
inline void pushdown(int id,int l,int r){
	lz[child(id)] += lz[id];
	lz[child(id)+1] += lz[id];
	d[child(id)] += 1ll * lz[id] * (mid(l,r)-l+1);
	d[child(id)+1] += 1ll * lz[id] * (r-mid(l,r));
	lz[id] = 0;
	return;
}
void update(int id,int l,int r,int s,int e,int op){
	if(s<=l && e>=r){
		lz[id] += op;
		d[id] += 1ll * op * (r-l+1);
	}
	else{
		pushdown(id,l,r);
		if(s <= mid(l,r))
			update(child(id),l,mid(l,r),s,e,op);
		if(e > mid(l,r))
			update(child(id)+1,mid(l,r)+1,r,s,e,op);
		d[id] = d[child(id)] + d[child(id)+1];
	}
	return;
}
ll_ int getsum(int id,int l,int r,int s,int e){
	if(s<=l && e>=r)
		return d[id];
	else{
		ll_ int ret = 0;
		pushdown(id,l,r);
		if(s <= mid(l,r))
			ret += getsum(child(id),l,mid(l,r),s,e);
		if(e > mid(l,r))
			ret += getsum(child(id)+1,mid(l,r)+1,r,s,e);
		return ret;
	}
}
void solve(void){
	int op;
	for(register int i = 0;i < m;++ i){
		cin >> op >> x >> y;
		if(op == 1){
			cin >> k;
			update(0,1,n,x,y,k);
		}
		else{
			cout << getsum(0,1,n,x,y) << '\n';
		}
	}
	return;
}
int main(void){
	input();
	build(0,1,n);
	solve();
	return 0;
}
