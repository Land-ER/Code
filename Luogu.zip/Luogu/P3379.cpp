#include<bits/stdc++.h>
int n,m,s;
std::vector<int> graph[500005];
int fa[32][500005],dep[500005];
void init(void){
    scanf("%d%d%d",&n,&m,&s);
    int a,b;
    for(int i = 0;i < n-1;++ i){
        scanf("%d%d",&a,&b);
        graph[a].push_back(b);
        graph[b].push_back(a);
    }
    return;
}
void dfs(int now,int father){
	static bool vis[500005];
    dep[now] = dep[father] + 1;
    fa[0][now] = father;
    vis[now] = 1;
    for(int i = 1;i < 32;++ i)
        fa[i][now] = fa[i-1][fa[i-1][now]];
    for(int i : graph[now])
        if(!vis[i])
        	dfs(i,now);
    return;
}
int lca(int a,int b){
    if(dep[a] > dep[b])
        std::swap(a,b);
    for(int i = 0,dif = dep[b]-dep[a];dif;++ i,dif >>= 1)
        if(dif & 1)
        	b = fa[i][b];
    if(a == b)
    	return a;
    for(int i = 31;i>=0 && a!=b;-- i)
        if(fa[i][a] != fa[i][b])
            a = fa[i][a],b = fa[i][b];
    return fa[0][a];
}
int main(void){
    init();
    dfs(s,0);
    int a,b;
    while(m --){
        scanf("%d%d",&a,&b);
        printf("%d\n",lca(a,b));
    }
    return 0;
}
