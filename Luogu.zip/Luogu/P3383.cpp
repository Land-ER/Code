#include<bits/stdc++.h>
using namespace std;
int main(void){
    vector<int> prime;
    bitset<100000005> isprime;
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    isprime.set();
    int n,q,k;
    cin >> n >> q;
    isprime[0] = isprime[1] = false;
    for(int i = 2;i <= n;++ i){
        if(isprime[i])
            prime.push_back(i);
        for(int j : prime){
            if(1ll*i*j > n)
                break;
            isprime[i*j] = false;
            if(!(i % j))
                break;
        }
    }
    while(q --){
        cin >> k;
        cout << prime[k-1] << '\n';
    }
    return 0;
}