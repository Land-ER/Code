#include<iostream>
#include<vector>
using namespace std;
struct ticket{
	long long int price,time;
};
unsigned int n;
int sum;
vector<ticket> subway;
ticket s;
bool tf;
long long int p,t;
int main(void){
	unsigned int i,j;
	bool k;
	cin >> n;
	for(i = 0;i < n;++ i){
		cin >> tf >> p >> t;
		if(!tf){
			s.price = p;
			s.time = t;
			subway.push_back(s);
			sum += p;
		}
		else{
			k = true;
			for(j = 0;j < subway.size();++ j){
				if(subway[j].price>=p && t-subway[j].time<=45){
					k = false;
					subway.erase(subway.begin()+j);
					break;
				}
			}
			if(k)
				sum += p;
		}
		#ifdef debug
		cout << sum << ' ';
		for(j = 0;j < subway.size();++ j){
			cout << subway[j].price << ' ' << subway[j].time << endl;
		}
		#endif
	}
	cout << sum;
	return 0;
}
