#include<bits/stdc++.h>
#define mod 998244353
int a[100005];
int main(void){
    int t;
    scanf("%d",&t);
    while(t--){
        int b,k;
        scanf("%d%d",&b,&k);
        memset(a,0,sizeof(a));
        int i = 2;
        while(b > 1){
            if(b % i)
                ++ i;
            else
                ++ a[i],b /= i;
        }
        long long int sum = 1;
        for(int j = 2;j <= i;++ j)
        	if(a[j])
            	sum = sum * ((1ll * a[j] * (k-1) + 1) % mod) % mod;
        printf("%lld\n",sum);
    }
    return 0;
}
