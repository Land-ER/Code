#include<bits/stdc++.h>
char s[5000000];
int tot = 0;
int main(void){
    char a[25],b[25];
    unsigned long long int n;
    char c;
    scanf("%s",s);
    while(true){
        c = s[tot++];
        if(c == '\0')
            break;
        else if(c == '{')
        	printf("{");
        else
            printf(",");
        if(s[tot] == '}')
            break;
        sscanf(s+tot,"%llu",&n);
        sprintf(a,"%llu",n);
        tot += strlen(a);
        sprintf(b,"%llX",n);
        if(strlen(a) < strlen(b)+2)
            printf("%s",a);
        else
            printf("0x%s",b);
    }
    printf("}");
    return 0;
}
