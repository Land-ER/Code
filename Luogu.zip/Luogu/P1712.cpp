#include<bits/stdc++.h>
int max(int a,int b){
    return a>b ? a : b;
}
int min(int a,int b){
    return a<b ? a : b;
}
class segment_tree{
    private:
        int d[4000050],t[4000050],size;
        void build(int id,int l,int r);
        void pushdown(int id);
        void modify(int id,int l,int r,int s,int e,int c);
        int query(int id,int l,int r,int s,int e);
    public:
        void init(int s);
        void modify(int s,int e,int c);
        int query(int s,int e);
}t;
#define lc (id<<1)
#define rc ((id<<1)+1)
#define mid ((l+r)>>1)
void segment_tree::build(int id,int l,int r){
    t[id] = 0;
    if(l == r)
        d[id] = 0;
    else{
        build(lc,l,mid);
        build(rc,mid+1,r);
        d[id] = max(d[lc],d[rc]);
    }
    return;
}
void segment_tree::pushdown(int id){
    d[lc] += t[id];
    d[rc] += t[id];
    t[lc] += t[id];
    t[rc] += t[id];
    t[id] = 0;
    return;
}
void segment_tree::modify(int id,int l,int r,int s,int e,int c){
    if(s<=l && e>=r){
        d[id] += c;
        t[id] += c;
    }else{
        pushdown(id);
        if(s <= mid)
            modify(lc,l,mid,s,e,c);
        if(e > mid)
            modify(rc,mid+1,r,s,e,c);
        d[id] = max(d[lc],d[rc]);
    }
    return;
}
int segment_tree::query(int id,int l,int r,int s,int e){
    if(s<=l && e>=r){
        return d[id];
    }else{
        int ret = ~0x7f7f7f7f;
        pushdown(id);
        if(s <= mid)
            ret = max(query(lc,l,mid,s,e),ret);
        if(e > mid)
            ret = max(query(rc,mid+1,r,s,e),ret);
        return ret;
    }
}
#undef lc
#undef rc
#undef mid
void segment_tree::init(int s){
    size = s;
    build(1,1,s);
    return;
}
void segment_tree::modify(int s,int e,int c){
    modify(1,1,size,s,e,c);
    return;
}
int segment_tree::query(int s,int e){
    return query(1,1,size,s,e);
}
std::unordered_map<int,int> p;
int init(int a[],int size){
	std::sort(a+1,a+size+1);
	int ret = std::unique(a+1,a+size+1) - a - 1;
	for(int i = 1;i <= ret;++ i)
		p.insert(std::make_pair(a[i],i));
	return ret;
}
struct segment{
    int l,r;
    bool operator<(const segment x)const{
        return (r-l) < (x.r-x.l);
    }
};
int main(void){
    int n,m;
    int a[1000005];
    segment s[500005];
    scanf("%d%d",&n,&m);
    for(int i = 1;i <= n;++ i){
        scanf("%d%d",&a[i*2-1],&a[i*2]);
        s[i].l = a[i*2-1],s[i].r = a[i*2];
    }
    int w = init(a,n*2);
    std::sort(s+1,s+n+1);
    int l = 1,r = 1,ans = 0x7f7f7f7f;
    t.init(w);
    while(r <= n){
        while(t.query(1,w) < m){
            t.modify(p[s[r].l],p[s[r].r],1);
            ++ r;
            if(r > n)
                break;
        }
        if(t.query(1,w) < m)
        	break;
        while(t.query(1,w) >= m){
            t.modify(p[s[l].l],p[s[l].r],-1);
            ++ l;
            if(l == r)
                break;
        }
        ans = min(s[r-1].r-s[r-1].l-s[l-1].r+s[l-1].l,ans);
    }
    if(ans == 0x7f7f7f7f)
        printf("-1\n");
    else
        printf("%d\n",ans);
    return 0;
}
