#include<bits/stdc++.h>
class fenwick{
    private:
        int s;
        long long int d[500050];
        int lowbit(int n){
            return n & -n;
        }
    public:
        void init(int a[],int size);
        void modify(int n,int c);
        long long int query(int l,int r);
};
void fenwick::init(int a[],int size){
    int k;
    s = size;
    for(int i = 1;i <= size;++ i){
        d[i] += a[i];
        k = i + lowbit(i);
        if(k <= s)
            d[k] += d[i];
    }
    return;
}
void fenwick::modify(int n,int c){
    while(n <= s){
        d[n] += c;
        n += lowbit(n);
    }
    return;
}
long long int fenwick::query(int l,int r){
    int n = r;
    long long int sum = 0;
    while(n >= 1){
        sum += d[n];
        n -= lowbit(n);
    }
    n = l-1;
    while(n >= 1){
        sum -= d[n];
        n -= lowbit(n);
    }
    return sum;
}
int p[500050];
fenwick f;
int main(void){
    int n,m,opt,x,y;
    scanf("%d%d",&n,&m);
    for(int i = 1;i <= n;++ i)
        scanf("%d",&p[i]);
    f.init(p,n);
    for(int i = 1;i <= m;++ i){
        scanf("%d%d%d",&opt,&x,&y);
        if(opt == 1)
            f.modify(x,y);
        else
            printf("%lld\n",f.query(x,y));
    }
    return 0;
}
