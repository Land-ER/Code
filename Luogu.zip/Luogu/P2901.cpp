#include<bits/stdc++.h>
int n,m,k;
struct edge{
    int v,w;
    bool operator<(const edge &_)const{
    	return w > _.w;
	}
};
std::vector<edge> graph[1005];
void init(void){
    int x,y,d;
    edge e;
    scanf("%d%d%d",&n,&m,&k);
    for(int i = 0;i < m;++ i){
        scanf("%d%d%d",&x,&y,&d);
        e.v = y;
        e.w = d;
        graph[x].push_back(e);
    }
    return;
}
int dis[1005];
void dijkstra(void){
    bool vis[1005];
    std::priority_queue<edge> q;
    memset(dis,0x3f,sizeof(dis));
    memset(vis,0,sizeof(vis));
    dis[1] = 0;
    edge d;
    d.v = 1,d.w = 0;
    q.push(d);
    while(!q.empty()){
    	int u = q.top().v;
    	q.pop();
    	if(vis[u])
    		continue;
    	vis[u] = 1;
    	for(auto v : graph[u]){
    		if(dis[u] + v.w < dis[v.v]){
    			dis[v.v] = dis[u] + v.w;
    			d.v = v.v;
    			d.w = dis[v.v];
    			q.push(d);
			}
		}
	}
	return;
}
struct data{
    int node,value;
    bool operator<(const data &_)const{
        return (value + dis[node]) > (_.value + dis[_.node]);
    }
};
void astar(void){
    std::priority_queue<data> q;
    data d,t;
    d.node = n,d.value = 0;
    q.push(d);
    while(!q.empty()){
        t = q.top();
        q.pop();
        if(t.node == 1){
            printf("%d\n",t.value);
            -- k;
            if(!k)
            	break;
            continue;
        }
        for(auto v : graph[t.node]){
            d.node = v.v,d.value = t.value + v.w;
            q.push(d);
        }
    }
    while(k--)
        printf("-1\n");
    return;
}
int main(void){
    init();
    dijkstra();
    astar();
    return 0;
}
