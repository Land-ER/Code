#include<bits/stdc++.h>
struct node{
    int l,r,lc,rc,value;
    int mid(void){
        return (l+r)/2;
    }
};
class rope{
    private:
        node n[2500005];
        int root[500005],tot,rt,length;
        int build(int l,int r,int t);
    public:
        rope(void);
        void init(int len,int t);
        void modify(int ver,int number,int value);
        int query(int ver,int number);
};
rope::rope(void){
    tot = rt = 0;
    return;
}
int rope::build(int l,int r,int t){
    int now = tot++;
    n[now].l = l,n[now].r = r;
    if(l == r){
        if(t)
            n[now].value = 1;
        else
            n[now].value = l;
    }
    else{
        n[now].lc = build(l,n[now].mid(),t);
        n[now].rc = build(n[now].mid()+1,r,t);
    }
    return now;
}
void rope::init(int len,int t){
    length = len;
    root[rt++] = build(1,length,t);
    return;
}
void rope::modify(int ver,int number,int value){
    if(!number)
        root[rt++] = root[ver];
    else{
        int now = tot++,r = root[ver];
        root[rt++] = now;
        while(n[r].l != n[r].r){
            n[now].l = n[r].l,n[now].r = n[r].r;
            if(number <= n[r].mid()){
                n[now].lc = tot++;
                n[now].rc = n[r].rc;
                now = n[now].lc;
                r = n[r].lc;
            }else{
                n[now].lc = n[r].lc;
                n[now].rc = tot++;
                now = n[now].rc;
                r = n[r].rc;
            }
        }
        n[now].l = n[r].l,n[now].r = n[r].r,n[now].value = value;
    }
    return;
}
int rope::query(int ver,int number){
    int r = root[ver];
    while(n[r].l != n[r].r){
        if(number <= n[r].mid())
            r = n[r].lc;
        else
            r = n[r].rc;
    }
    return n[r].value;
}
class persistentSetUnion{
    private:
        int length,ver,now;
        rope father,rank;
        int find(int x);
    public:
        void init(int len);
        void merge(int a,int b);
        void rollback(int k);
        bool query(int a,int b);
};
void persistentSetUnion::init(int len){
    length = len;
    ver = 0,now = 1;
    father.init(len,0);
    rank.init(len,1);
    return;
}
int persistentSetUnion::find(int x){
    int r = father.query(ver,x);
    while(x != r)
        x = r,r = father.query(ver,r);
    return r;
}
void persistentSetUnion::merge(int a,int b){
    int x = find(a),y = find(b);
    int p = rank.query(ver,x),q = rank.query(ver,y);
    if(p < q)
        father.modify(ver,x,y);
    else
        father.modify(ver,y,x);
    if(p == q)
        rank.modify(ver,x,p+1);
    else
        rank.modify(ver,0,0);
    ver = now++;
    return;
}
void persistentSetUnion::rollback(int k){
    ver = k;
    father.modify(ver,0,0);
    rank.modify(ver,0,0);
    ++ now;
    return;
}
bool persistentSetUnion::query(int a,int b){
    bool flag;
    if(find(a) == find(b))
        flag = 1;
    else
        flag = 0;
    father.modify(ver,0,0);
    rank.modify(ver,0,0);
    ++ now;
    return flag;
}
persistentSetUnion dsu;
int main(void){
    int n,m,op,x,y;
    scanf("%d%d",&n,&m);
    dsu.init(n);
    while(m--){
        scanf("%d%d",&op,&x);
        if(op == 1){
            scanf("%d",&y);
            dsu.merge(x,y);
        }else if(op == 2){
            dsu.rollback(x);
        }else{
            scanf("%d",&y);
            if(dsu.query(x,y))
                printf("1\n");
            else
                printf("0\n");
        }
    }
    return 0;
}
