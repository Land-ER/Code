#include<bits/stdc++.h>
int max(int a,int b){
    return a>b ? a : b;
}
int main(void){
    int t,n,m;
    int p[105][1005],dp[10005];
    scanf("%d%d%d",&t,&n,&m);
    for(int i = 1;i <= t;++ i)
        for(int j = 1;j <= n;++ j)
            scanf("%d",&p[i][j]);
    for(int i = 1;i <= t-1;++ i){
    	memset(dp,0,sizeof(dp));
        for(int j = 1;j <= n;++ j){
            for(int k = p[i][j];k <= m;++ k){
                dp[k] = max(dp[k-p[i][j]]+p[i+1][j]-p[i][j],dp[k]);
            }
        }
        m = dp[m]+m;
    }
    printf("%d",m);
    return 0;
}
