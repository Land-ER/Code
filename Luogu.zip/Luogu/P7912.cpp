#include<cstdio>
struct node{
	char type;
	int next,l,r;
}a[200005];
int start = 1,end = 1;
void input(void){
	register int n,i;
	register char k = '2';
	scanf("%d",&n);
	while(!(k=='1' || k=='0'))
		k = getchar();
	a[1].l = 1;
	a[1].r = 1;
	a[1].type = k;
	a[1].next = 1;
	getchar();
	for(i = 2;i <= n;++ i){
		k = getchar();
		if(a[end].type == k)
			++ a[end].r;
		else{
			a[end].next = end + 1;
			++ end;
			a[end].type = k;
			a[end].l = i;
			a[end].r = i;
		}
		getchar();
	}
	a[end].next = end + 1;
	++ end;
	return;
}
void solve(void){
	register int i;
	register char la;
	while(start < end){
		la = '2';
		for(i = start;i < end; ){
			if(a[i].type == la){
				i = a[i].next;
			}
			else{
				printf("%d ",a[i].l);
				la = a[i].type;
				++ a[i].l;
				if(a[i].l > a[i].r){
					if(i == start){
						start = a[i].next;
						i = start;
					}
					else{
						a[i-1].next = a[i].next;
						i = a[i].next;
					}
				}
				else{
					i = a[i].next;
				}
			}
		}
		printf("\n");
	}
}
int main(void){
	input();
	solve();
	return 0;
}
