#include<cstdio>
int n,m;
int z,x,y;
int father[10000];
void initialize(void){
	for(int i = 0;i < 1e4;++ i)
		father[i] = i;
	return;
}
int find(int a){
	if(father[a] != a)
		father[a] = find(father[a]);
	return father[a];
}
void make(int a,int b){
	int fa,fb;
	fa = find(a);
	fb = find(b);
	father[fb] = fa;
	return;
}
bool search(int a,int b){
	int fa,fb;
	fa = find(a);
	fb = find(b);
	if(fa == fb)
		return true;
	else
		return false;
}
int main(void){
	initialize();
	scanf("%d%d",&n,&m);
	for(int i = 0;i < m;++ i){
		scanf("%d%d%d",&z,&x,&y);
		if(z == 1)
			make(x,y);
		if(z == 2){
			if(search(x,y))
				printf("Y\n");
			else
				printf("N\n");
		}
	}
	return 0;
}
