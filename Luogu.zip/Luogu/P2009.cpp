#include<iostream>
using namespace std;
int dis[25][25];
bool vis[25][25];
int n,k;
inline int max(int n,int s,int e){
	if(vis[s][e] == 0){
		vis[s][e] = 1;
		return n;
	}
	else
		return n>dis[s][e] ? n : dis[s][e];
}
inline int min(int a,int b){
	return a<b ? a : b;
}
void input(void){
	cin >> n >> k;
	int i,j,a,b;
	char s,e;
	for(i = 0;i < n-1;++ i){
		cin >> j;
		dis[i][i+1] = max(j,i,i+1);
		dis[i+1][i] = max(j,i+1,i);
	}
	cin >> j;
	dis[n-1][0] = max(j,n-1,0);
	dis[0][n-1] = max(j,0,n-1);
	for(i = 0;i < k;++ i){
		cin >> s >> e >> j;
		a = s - 'A';
		b = e - 'A';
		dis[a][b] = max(j,a,b);
		dis[b][a] = max(j,b,a);
	}
	for(i = 0;i < n;++ i)
		for(j = 0;j < n;++ j)
			if(!vis[i][j])
				dis[i][j] = 0x3f3f3f3f;
	return;
}
void floyd(void){
	int i,j,k;
	char s,e;
	cin >> s >> e;
	for(i = 0;i < n;++ i)
		for(j = 0;j < n;++ j)
			for(k = 0;k < n;++ k)
				dis[i][j] = min(dis[i][j],dis[i][k]+dis[k][j]);
	cout << dis[s-'A'][e-'A'];
}
int main(void){
	input();
	floyd();
	return 0;
}
