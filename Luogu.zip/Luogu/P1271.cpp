#include<cstdio>
int main(void){
	int list[1005] = {0};
	int n,m;
	int i,j;
	scanf("%d%d",&n,&m);
	for(i = 0;i < m;++ i){
		scanf("%d",&j);
		++ list[j];
	}
	for(i = 1;i <= n;++ i)
		for(j = 0;j < list[i];++ j)
			printf("%d ",i);
	return 0;
}
