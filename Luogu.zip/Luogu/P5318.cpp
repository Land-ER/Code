#include<bits/stdc++.h>
using namespace std;
int n,m;
vector<int> graph[100005];
bitset<100005> vis;
void init(void){
    cin >> n >> m;
    int u,v;
    while(m --){
        cin >> u >> v;
        graph[u].push_back(v);
    }
    for(int i = 1;i <= n;++ i)
        sort(graph[i].begin(),graph[i].end());
    return;
}
void dfs(int now){
    cout << now << ' ';
    vis[now] = 1;
    for(int t : graph[now])
        if(!vis[t])
            dfs(t);
    return;
}
void bfs(void){
    queue<int> q;
    int u;
    vis.reset();
    vis[1] = 1;
    q.push(1);
    while(!q.empty()){
        u = q.front();
        q.pop();
        for(int v : graph[u]){
            if(vis[v])
                continue;
            vis[v] = 1;
            q.push(v);
            cout << v << ' ';
        }
    }
    cout << endl;
    return;
}
int main(void){
    init();
    dfs(1);
    cout << endl << 1 << ' ';
    bfs();
}