#include<iostream>
#include<cstring>
#define int long long
#define mod 1000000007
using namespace std;
struct matrix{
	int t[3][3],x,y;
	matrix(int a,int b){
		x = a;
		y = b;
		memset(t,0,sizeof(t));
	}
};
matrix operator*(const matrix& a,const matrix& b){
	matrix ret(a.y,b.x);
	for(signed i = 1;i <= a.y;++ i){
		for(signed j = 1;j <= b.x;++ j){
			int sum = 0;
			for(signed k = 1;k <= a.x;++ k){
				sum += a.t[k][i] * b.t[j][k] % mod;
			}
		}
	}
}
