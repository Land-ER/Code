#include<iostream>
#include<cmath>
using namespace std;
void solve(void){
	long long int n,m,a,b,ret;
	cin >> n >> m;
	for(a = sqrt(n);a >= 1;-- a)
		if(!(n%a))
			break;
	b = n/a;
	ret = 2*(a+b+2);
	if(ret > m)
		cout << "Miss\n";
	else
		cout << "Good\n";
	return;
}
int main(void){
	int i,t;
	cin >> t;
	for(i = 0;i < t;++ i)
		solve();
	return 0;
}
