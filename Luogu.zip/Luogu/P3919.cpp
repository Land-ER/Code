#include<bits/stdc++.h>
int a[1000005],n,m;
struct node{
	int l,r,lc,rc,value;
}d[25000025];
int root[2000015],rt,tot;
#define mid ((l+r)>>1)
int build(int l,int r){
	int now = tot++;
	d[now].l = l,d[now].r = r;
	if(l == r)
		d[now].lc = -1,d[now].rc = -1,d[now].value = a[l];
	else{
		d[now].lc = build(l,mid);
		d[now].rc = build(mid+1,r);
	}
	return now;
}
void modify(int ver,int num,int val){
	int n = root[ver];
	root[rt++] = tot;
	int l = d[n].l,r = d[n].r;
	while(l != r){
		d[tot].l = l,d[tot].r = r;
		if(num <= mid)
			d[tot].lc = tot+1,d[tot].rc = d[n].rc,n = d[n].lc,r = mid,++ tot;
		else
			d[tot].lc = d[n].lc,d[tot].rc = tot+1,n = d[n].rc,l = mid+1,++ tot;
	}
	d[tot].l = l,d[tot].r = r,d[tot].lc = -1,d[tot].rc = -1,d[tot].value = val,++ tot;
	return;
}
int query(int ver,int id){
	int n = root[ver];
	root[rt++] = n;
	int l = d[n].l,r = d[n].r;
	while(l != r){
		if(id <= mid)
			n = d[n].lc,r = mid;
		else
			n = d[n].rc,l = mid + 1;
	}
	return d[n].value;
}
int main(void){
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;++ i)
		scanf("%d",&a[i]);
	root[rt++] = build(1,n);
	for(int i = 1;i <= m;++ i){
		int v,op,loc,val;
		scanf("%d%d%d",&v,&op,&loc);
		if(op == 1){
			scanf("%d",&val);
			modify(v,loc,val);
		}else
			printf("%d\n",query(v,loc));
	}
	return 0;
}