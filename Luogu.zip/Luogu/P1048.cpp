#include<iostream>
using namespace std;
int t,m;
int w[100],c[100];
int dp[1000];
int max(int a,int b){
	return a>b ? a : b;
}
void input(void){
	int i;
	cin >> t >> m;
	for(i = 0;i < m;++ i)
		cin >> w[i] >> c[i];
	return;
}
void make(void){
	int i,j;
	dp[0] = 0;
	for(i = 0;i < m;++ i)
		for(j = t-1;j >= w[i]-1;-- j)
			dp[j] = max(dp[j],dp[j-w[i]]+c[i]);
	cout << dp[t-1];
	return;
}
int main(void){
	input();
	make();
	return 0;
}
