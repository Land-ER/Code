#include<iostream>
#include<algorithm>
using namespace std;
int list[100005];
int f[100005];
int w[100005];
int len,f_len=1,w_len=1,m;
bool cmp(const int &a,const int &b){
	return a>b;
}
void input(void){
	for(len = 0;cin >> list[len];++ len);
	return;
}
void solve1(void){
	int *pt;
	f[0] = list[0];
	for(int count = 1;count < len;++ count){
		pt = upper_bound(f,f+f_len,list[count],cmp);
		if(*pt == 0)
			++ f_len;
		*pt = list[count];
	}
	cout << f_len << endl;
	return;
}
void solve2(void){
	w[0] = list[0];
	for(int i = 1;i < len;++ i){
		m = -1;
		for(int j = 0;j < w_len;++ j){
			if(m != -1){
				if(w[j]>=list[i] && w[j]<w[m])
					m = j;
			}
			else{
				if(w[j] >= list[i])
					m = j;
			}
		}
		if(m == -1){
			w[w_len] = list[i];
			++ w_len;
		}
		else
			w[m] = list[i];
	}
	cout << w_len;
}
int main(void){
	input();
	solve1();
	solve2();
	return 0;
}
