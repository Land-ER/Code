#include<iostream>
using namespace std;
int main(void){
	int input;
	cin >> input;
	if(input == 1)
		cout << "1\n1 1";
	else if(input == 2)
		cout << "4\n1 1\n2 1\n2 2\n1 2";
	else
		cout << "-1";
	return 0;
}
