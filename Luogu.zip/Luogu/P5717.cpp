#include<iostream>
#include<string>
using namespace std;
string str[6] = {"Not triangle","Right triangle","Acute triangle","Obtuse triangle","Isosceles triangle","Equilateral triangle"};
long long int a,b,c,aa,bb,cc;
inline void swap(long long int &num1,long long int &num2){
	long long int num3 = num1;
	num1 = num2;
	num2 = num3;
	return;
}
void sort(){
	if(a > b)
		swap(a,b);
	if(b > c)
		swap(b,c);
	if(a > b)
		swap(a,b);
	return;
}
int main(void){
	cin >> a >> b >> c;
	sort();
	if(a+b <= c)
		cout << str[0];
	else{
		aa = 1ll * a * a;
		bb = 1ll * b * b;
		cc = 1ll * c * c;
		if(aa+bb == cc)
			cout << str[1] << '\n';
		else if(aa+bb > cc)
			cout << str[2] << '\n';
		else
			cout << str[3] << '\n';
		if(a==b || b==c)
			cout << str[4] << '\n';
		if(a==b && b==c)
			cout << str[5];
	}
	return 0;
}
