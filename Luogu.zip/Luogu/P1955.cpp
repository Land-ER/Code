#include<bits/stdc++.h>
using namespace std;
int t,n,p;
vector<pair<long long int,long long int> > eq,neq;
unordered_map<long long int,int> m;
vector<int> dsu;
void init(void){
	eq.clear();
	neq.clear();
	m.clear();
	dsu.clear();
	p = 0;
	cin >> n;
	long long int i,j,e;
	for(int k = 0;k < n;++ k){
		cin >> i >> j >> e;
		if(m.find(i) == m.end())
			m.insert(make_pair(i,p++));
		if(m.find(j) == m.end())
			m.insert(make_pair(j,p++));
		if(e)
			eq.push_back(make_pair(m[i],m[j]));
		else
			neq.push_back(make_pair(m[i],m[j]));
	}
	for(int k = 0;k < p;++ k)
		dsu.push_back(k); 
	return;
}
int find(int x){
	if(dsu[x] != x)
		dsu[x] = find(dsu[x]);
	return dsu[x];
}
void merge(int a,int b){
	dsu[find(a)] = find(b);
	return;
}
void solve(void){
	for(auto pt = eq.begin();pt != eq.end();++ pt)
		merge(pt->first,pt->second);
	bool flag = true;
	for(auto pt = neq.begin();pt != neq.end();++ pt){
		if(find(pt->first) == find(pt->second)){
			flag = false;
			break;
		}
	}
	if(flag)
		cout << "YES\n";
	else
		cout << "NO\n";
	return;
}
int main(void){
	cin >> t;
	while(t--){
		init();
		solve();
	}
	return 0;
}
