#include<iostream>
#include<algorithm>
#define mod_ 998244353
using namespace std;
long long dp[4][800005],a,b,c,n;
void solve(void){
	cin >> n >> a >> b >> c;
	register int i;
	dp[0][0] = 2;
	dp[1][0] = 1;
	dp[2][0] = 1;
	dp[3][0] = 1;
	for(i = min(min(a,b),c);i < max(max(a,b),c);++ i){
		if(i-a >= 0)
			dp[1][i] = (dp[1][i] + dp[0][i-a] - dp[1][i-a]) % mod_;
		if(i-b >= 0)
			dp[2][i] = (dp[2][i] + dp[0][i-b] - dp[2][i-b]) % mod_;
		if(i-c >= 0)
			dp[3][i] = (dp[3][i] + dp[0][i-c] - dp[3][i-c]) % mod_;
		dp[0][i] = (dp[1][i] + dp[2][i] + dp[3][i]) % mod_;
	}
	for( ;i <= n;++ i){
		dp[1][i] = (dp[1][i] + dp[0][i-a] - dp[1][i-a]) % mod_;
		dp[2][i] = (dp[2][i] + dp[0][i-b] - dp[2][i-b]) % mod_;
		dp[3][i] = (dp[3][i] + dp[0][i-c] - dp[3][i-c]) % mod_;
		dp[0][i] = (dp[1][i] + dp[2][i] + dp[3][i]) % mod_;
	}
	cout << dp[0][n];
	return;
}
int main(void){
	solve();
	return 0;
}
