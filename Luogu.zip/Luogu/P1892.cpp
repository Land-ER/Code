#include<iostream>
using namespace std;
int f[1005],e[1005],c[1005],n,m;
void init(void){
	for(int i = 0;i < n;++ i)
		f[i] = i;
	return;
}
int ff(int id){
	if(f[id] == id)
		return id;
	else{
		f[id] = ff(f[id]);
		return f[id];
	}
}
inline void mf(int a,int b){
		f[a] = f[b];
	return;
}
void solve(void){
	cin >> n >> m;
	char opt;
	int p,q;
	init();
	for(int i = 0;i < m;++ i){
		cin >> opt >> p >> q;
		if(opt == 'F')
			mf(p,q);
		else{
			if(e[p] != 0)
				mf(q,e[p]);
			else
				e[p] = q;
			if(e[q] != 0)
				mf(p,e[q]);
			else
				e[q] = p;
		}
	}
	int cnt = 0;
	for(int i = 0;i < n;++ i)
		++ c[ff(i)];
	for(int i = 0;i < n;++ i)
		if(c[i])
			++ cnt;
	cout << cnt;
	return;
}
int main(void){
	solve();
	return 0;
}
