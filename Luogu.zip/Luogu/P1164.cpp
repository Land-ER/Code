#include<iostream>
using namespace std;
int n,m;
int a[1000];
int dp[10000];
void input(void){
	cin >> n >> m;
	for(int i = 0;i < n;++ i)
		cin >> a[i];
	return;
}
void make(void){
	int i,j;
	dp[0] = 1;
	for(i = 0;i < n;++ i)
		for(j = m;j >= a[i];-- j)
			dp[j] += dp[j-a[i]];
	cout << dp[m];
	return;
}
int main(void){
	input();
	make();
	return 0;
}
