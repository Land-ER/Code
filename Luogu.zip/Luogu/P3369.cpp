#include<bits/stdc++.h>
typedef int ptr;
using std::pair;
using std::make_pair;
class treap{
    private:
        int value[100005],count[100005],size[100005],priority[100005];
        ptr root,tot,lc[100005],rc[100005];
        void resize(ptr n);
        pair<ptr,ptr> split(ptr n,int key);
        ptr merge(ptr a,ptr b);
    public:
        treap(void);
        void insert(int key);
        void erase(int key);
        int query_by_value(int key);
        int query_by_rank(int key);
        int lower_bound(int key);
        int rlower_bound(int key);
};
treap::treap(void){
	memset(lc,0,sizeof(lc));
	memset(rc,0,sizeof(rc));
	value[0] = 0;
	count[0] = 0;
	size[0] = 0;
    tot = 1;
    return;
}
void treap::resize(ptr n){
    size[n] = size[lc[n]] + size[rc[n]] + count[n];
    return;
}
pair<ptr,ptr> treap::split(ptr n,int key){
    if(!n)
        return make_pair(0,0);
    pair<ptr,ptr> p;
    if(key < value[n]){
        p = split(lc[n],key);
        lc[n] = p.second;
        resize(n);
        return make_pair(p.first,n);
    }else{
        p = split(rc[n],key);
        rc[n] = p.first;
        resize(n);
        return make_pair(n,p.second);
    }
}
ptr treap::merge(ptr a,ptr b){
    if(!a)
        return b;
    if(!b)
        return a;
    if(priority[a] > priority[b]){
        rc[a] = merge(rc[a],b);
        resize(a);
        return a;
    }else{
        lc[b] = merge(a,lc[b]);
        resize(b);
        return b;
    }
}
void treap::insert(int key){
    static std::mt19937 rnd(0);
    pair<ptr,ptr> p = split(root,key);
    ptr q = p.first;
    while(rc[q])
        q = rc[q];
    if(q && value[q]==key){
        ++ count[q];
        ptr u = p.first;
        while(rc[u])
            ++ size[u],u = rc[u];
        ++ size[u];
        root = merge(p.first,p.second);
    }else{
        value[tot] = key;
        priority[tot] = rnd();
        count[tot] = 1;
        size[tot] = 1;
        root = merge(p.first,tot);
        root = merge(root,p.second);
        ++ tot;
    }
    return;
}
void treap::erase(int key){
    pair<ptr,ptr> p = split(root,key);
    ptr q = p.first;
    while(rc[q])
        q = rc[q];
    if(value[q]==key && count[q]>1){
        -- count[q];
        ptr u = p.first;
        while(rc[u])
            -- size[u],u = rc[u];
        -- size[u];
        root = merge(p.first,p.second);
    }else if(value[q] == key){
        pair<ptr,ptr> w = split(p.first,key-1);
        root = merge(w.first,p.second);
    }
    return;
}
int treap::query_by_value(int key){
    ptr p = root;
    int ret = 1;
    while(key != value[p]){
        if(key < value[p])
            p = lc[p];
        else{
            ret += count[p] + size[lc[p]];
            p = rc[p];
        }
    }
    ret += size[lc[p]];
    return ret;
}
int treap::query_by_rank(int key){
    ptr p = root;
    while(true){
        if(size[lc[p]]<key && count[p]+size[lc[p]] >= key)
            break;
        else if(size[lc[p]] >= key)
            p = lc[p];
        else
            key -= count[p] + size[lc[p]],p = rc[p];
    }
    return value[p];
}
int treap::lower_bound(int key){
    pair<ptr,ptr> p = split(root,key-1);
    ptr q = p.first;
    while(rc[q])
        q = rc[q];
    root = merge(p.first,p.second);
    return value[q];
}
int treap::rlower_bound(int key){
    pair<ptr,ptr> p = split(root,key);
    ptr q = p.second;
    while(lc[q])
        q = lc[q];
    root = merge(p.first,p.second);
    return value[q];
}
int main(void){
	freopen("input6.in","r",stdin);
	freopen("input6.ans","w",stdout);
    treap t;
    int n,opt,x;
    scanf("%d",&n);
    while(n --){
        scanf("%d%d",&opt,&x);
        switch(opt){
            case 1:
                t.insert(x);
                break;
            case 2:
                t.erase(x);
                break;
            case 3:
                printf("%d\n",t.query_by_value(x));
                break;
            case 4:
                printf("%d\n",t.query_by_rank(x));
                break;
            case 5:
                printf("%d\n",t.lower_bound(x));
                break;
            case 6:
                printf("%d\n",t.rlower_bound(x));
                break;
            default:
                ;
        }
        fflush(stdout);
    }
    return 0;
}
