#include<cstdio>
int n,w,list[601];
inline int divide(int num){
	int ret = num * w / 100;
	return ret>1 ? ret : 1;
}
int main(void){
	int score,find;
	int i,j;
	scanf("%d%d",&n,&w);
	for(i = 1;i <= n;++ i){
		scanf("%d",&score);
		++ list[score];
		find = divide(i);
		for(j = 600;find > 0;-- j)
			find -= list[j];
		printf("%d ",j+1);
	}
	return 0;
}
