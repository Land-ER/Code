#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
inline int max(int a,int b){
	return a>b ? a : b;
}
class Big{
	public:
		int number[1000];
		int len;
		Big(){
			memset(number,0,sizeof(number));
			len = 0;
		}
		void make(void);
		void read(void);
		void write(void);
};
void Big::read(void){
	char input[2005];
	int l,i,w,k;
	cin >> input;
	for(l = 0;input[l] != '\0';++ l);
	for(i = --l;i >= 0;-- i){
		w = l - i;
		if(!(w%4)){
			++ len;
			k = 1;
		}
		number[w/4] += (input[i]-'0') * k;
		k *= 10;
	}
	return;
}
void Big::write(void){
	int k;
	int l = len - 1;
	cout << number[l];
	for(-- l;l >= 0;-- l){
		for(k = 1000;k>number[l] && k>1;k /= 10){
			cout << 0;
		}
			cout << number[l];
	}
	return;
}
void Big::make(){
	for(int i = 0;i < len-1;++ i){
		number[i+1] += number[i] / 10000;
		number[i] %= 10000;
	}
	return;
}
Big operator*(const Big& a,const Big& b){
	Big ret;
	ret.len = a.len + b.len - 1;
	int i,j;
	for(i = 0;i < a.len;++ i){
		for(j = 0;j < b.len;++ j){
			ret.number[i+j] += a.number[i] * b.number[j];
		}
	}
	ret.make();
	return ret;
}
int main(void){
	Big a,b,ret;
	a.read();
	b.read();
	ret = a * b;
	ret.write();
	return 0;
}
