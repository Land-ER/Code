#include<bits/stdc++.h>
int max(int a,int b){
    return a>b ? a : b;
}
int main(void){
    int v,n,w[35],dp[20005];
    memset(dp,0,sizeof(dp));
    scanf("%d%d",&v,&n);
    for(int i = 1;i <= n;++ i)
        scanf("%d",w+i);
    for(int i = 1;i <= n;++ i)
        for(int j = v;j-w[i] >= 0;-- j)
            dp[j] = max(dp[j-w[i]]+w[i],dp[j]);
    printf("%d",v-dp[v]);
    return 0;
}