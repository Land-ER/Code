#include<iostream>
#include<cmath>
using namespace std;
int t;
long long int a,b,c,d;
long long int dis,dis_x,dis_y;
long long int ret;
inline long long int min(long long int a,long long int b){
	return a<b ? a : b;
}
inline long long int max(long long int a,long long int b){
	return a>b ? a : b;
}
void input(void){
	cin >> a >> b >> c >> d;
	return;
}
void make(void){
	dis_x = abs(a-c);
	dis_y = abs(b-d);
	dis = min(dis_x,dis_y);
	ret = dis * 2;
	dis_x -= dis;
	dis_y -= dis;
	dis = max(dis_x,dis_y);
	ret += 2*dis - dis%2;
	cout << ret << '\n';
	return;
}
int main(void){
	cin >> t;
	for(int i = 0;i < t;++ i){
		input();
		make();
	}
	return 0;
}
