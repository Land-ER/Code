#include<cstdio>
int n,d[1000005],t[1000005];
#define lc (id<<1)
#define rc ((id<<1)|1)
#define mid ((l+r)>>1)
void build(int id,int l,int r){
    if(l == r)
        d[id] = 1;
    else{
        build(lc,l,mid);
        build(rc,mid+1,r);
        d[id] = d[lc] + d[rc];
    }
    return;
}
int make(int id,int l,int r,int s,int e){
    if(l == r)
        d[id] = 0;
    else{
        if(t[id])
            return 0;
        if(s<=l && e>=r)
            d[id] = 0,t[id] = 1;
        else{
            if(s <= mid)
                make(lc,l,mid,s,e);
            if(e > mid)
                make(rc,mid+1,r,s,e);
            d[id] = d[lc] + d[rc];
        }
    }
    return d[id];
}
int main(void){
    int m;
    scanf("%d%d",&n,&m);
    int l,r;
    build(1,1,n);
    while(m --){
        scanf("%d%d",&l,&r);
        printf("%d\n",make(1,1,n,l,r));
    }
    return 0;
}