#include<bits/stdc++.h>
using namespace std;
unordered_set<int> s;
int main(void){
    int t,n,x;
    cin >> t;
    while(t--){
        s.clear();
        cin >> n;
        while(n--){
            cin >> x;
            if(s.find(x) == s.end())
                s.insert(x),cout << x << ' ';
        }
        cout << '\n';
    }
    return 0;
}