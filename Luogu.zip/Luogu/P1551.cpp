#include<iostream>
using namespace std;
int father[5005];
void make(void){
	for(int i = 0;i < 5005;++ i)
		father[i] = i;
	return;
}
int find(int a){
	if(father[a] != a)
		father[a] = find(father[a]);
	return father[a];
}
void unionn(int a,int b){
	father[find(b)] = find(a);
	return;
}
bool get(int a,int b){
	if(father[find(a)] == father[find(b)])
		return true;
	else
		return false;
}
int main(void){
	int n,m,p;
	make();
	cin >> n >> m >> p;
	int a,b;
	for(int i = 0;i < m;++ i){
		cin >> a >> b;
		unionn(a,b);
	}
	for(int i = 0;i < p;++ i){
		cin >> a >> b;
		if(get(a,b))
			cout << "Yes\n";
		else
			cout << "No\n";
	}
	return 0;
}
