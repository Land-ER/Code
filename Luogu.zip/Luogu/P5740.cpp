#include<cstdio>
struct student{
	char name[9];
	int chinese,math,english;
	int score(void){
		return chinese + math + english;
	}
};
int main(void){
	student students[1005],max;
	int n;
	scanf("%d",&n);
	for(int i = 0;i < n;++ i)
		scanf("%s%d%d%d",students[i].name,&students[i].chinese,&students[i].math,&students[i].english);
	max = students[0];
	for(int i = 1;i < n;++ i)
		max = max.score()>=students[i].score() ? max : students[i];
	printf("%s %d %d %d",max.name,max.chinese,max.math,max.english);
	return 0;
}
