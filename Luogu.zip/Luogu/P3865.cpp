#include<bits/stdc++.h>
int lg[100005],st[20][100005],n,m;
int max(int a,int b){
    return a>b ? a : b;
}
void read(void){
    for(int i = 1;i <= n;++ i)
        scanf("%d",&st[0][i]);
    return;
}
void init(void){
    for(int i = 1,j = 0;i <= n;i <<= 1,++ j)
        lg[i] = j;
    for(int i = 2;i <= n;++ i)
        if(!lg[i])
            lg[i] = lg[i-1];
    for(int k = 1;1<<k <= n;++ k)
        for(int i = 1;i+(1<<k)-1 <= n;++ i)
            st[k][i] = max(st[k-1][i],st[k-1][i+(1<<(k-1))]);
    return;
}
int query(int l,int r){
    int k = lg[(r-l+1)];
    return max(st[k][l],st[k][r-(1<<k)+1]);
}
int main(void){
    scanf("%d%d",&n,&m);
    read();
    init();
    int l,r;
    for(int i = 1;i <= m;++ i){
        scanf("%d%d",&l,&r);
        printf("%d\n",query(l,r));
    }
    return 0;
}
