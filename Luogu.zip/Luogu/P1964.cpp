#include<iostream>
#include<string>
#include<map>
using namespace std;
int m,n,a,b,c;string str;
struct t{
	int a,b,c;
	t(void){
		a = 0;b = 0;c = 0;
		return;
	}
};
map<str,t> l;
void input(void){
	cin >> m >> n;
	m = 21 - m;
	for(int i = 0;i < n;++ i){
		cin >> a >> b >> c >> str;
		l[str].a += a;
		l[str].b += b;
		l[str].c += c;
	}
	return;
}
void solve(void){
	
}
