#include<cstdio>
#include<cstring>
//#define debug
int t;
int q[200005];
bool c[10000505];
int m;
void input(void){
	scanf("%d",&t);
	memset(c,1,sizeof(c));
	for(int i = 0;i < t;++ i){
		scanf("%d",&q[i]);
		m = q[i]>m ? q[i] : m;
	}
	m += 500;
	return;
}
int num[10],top,pt,n;
int sum;
void make(void){
	int i,j,k;
	c[7] = 0;
	
	return;
}
void solve(void){
	int i,j;
	for(i = 0;i < t;++ i){
		if(!c[q[i]])
			printf("-1\n");
		else{
			for(j = q[i]+1;!c[j];++ j);
			printf("%d\n",j);
		}
	}
}
int main(void){
	input();
	make();
	solve();
	return 0;
}
