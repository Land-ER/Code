#include<bits/stdc++.h>
int max(int a,int b){
    return a>b ? a : b;
}
int main(void){
    int n,m;
    int v[30],w[30];
    int dp[30005];
    memset(dp,0,sizeof(dp));
    scanf("%d%d",&n,&m);
    for(int i = 1;i <= m;++ i)
        scanf("%d%d",v+i,w+i);
    for(int i = 1;i <= m;++ i)
        for(int j = n;j-v[i] >= 0;-- j)
            dp[j] = max(dp[j-v[i]]+v[i]*w[i],dp[j]);
    printf("%d",dp[n]);
    return 0;
}
