#include<cstdio>
int main(void){
	int n,ret = 1;
	scanf("%d",&n);
	for(int i = 1;i < n;++ i)
		ret = (ret+1) * 2;
	printf("%d",ret);
	return 0;
}
