#include<iostream>
using namespace std;
int t;
int n,m,k;
long long int mn;
long long int mod;
int list[1000005];
void input(void){
	cin >> n >> m >> k;
	return;
}
void pop(void){
	for(int count = 0;count < m;++ count)
		cout << list[count] << ' ';
	cout << '\n';
	return;
}
void print(void){
	bool tf = true;
	int a,b = 1,i = 0,j = 0;
	while(true){
		for(a = 0;a < k;++ a){
			if(tf){
				list[i] = b;
				if(i + 1 == m){
					pop();
					if(j+1 == n)
						goto breaking;
					++ j;
					tf = false;
				}
				else
					++ i;
			}
			else{
				list[i] = b;
				if(i == 0){
					pop();
					if(j+1 == n)
						goto breaking;
					++ j;
					tf = true;
				}
				else
					-- i;
			}
		}
		++ b;
	}
	breaking:
		return;
}
void make(void){
	mn = 1ll * n * m;
	mod = mn % k;
	if(mod == 0){
		cout << "YES\n";
		print();
	}
	else
		cout << "NO\n";
	return;
}
int main(void){
	cin >> t;
	for(int count = 0;count < t;++ count){
		input();
		make();
	}
	return 0;
}
