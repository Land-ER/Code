#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
int dis[1005];bool vis[1005];
vector<int> g[1005];
void input(void){
    int u,v;
    scanf("%d%d%d",&u,&u,&v);
    for(int i = 0;i < 1800;++ i){
        scanf("%d%d",&u,&v);
        g[u].push_back(v);
        g[v].push_back(u);
    }
    return;
}
void spfa(void){
    int i,u,v;
    queue<int> q;
    memset(dis,0x3f,sizeof(dis));
    for(i = 51;i <= 100;++ i){
        dis[i] = 0;
        vis[i] = 1;
        q.push(i);
    }
    while(!q.empty()){
        u = q.front();q.pop();
        vis[u] = 0;
        for(auto pt = g[u].begin();pt < g[u].end();++ pt){
            v = *pt;
            if(dis[v] > dis[u] + 1){
                dis[v] = dis[u] + 1;
                vis[v] = 1;
                q.push(v);
            }
        }
    }
    return;
}
void solve(void){
    input();
    spfa();
    queue<int> q;
    vector<pair<int,int> > t[1005];
    int i;
    for(i = 1;i <= 50;++ i){
        q.push(i);
        t[i].push_back(make_pair(0,0));
    }
    while(!q.empty()){
        int tof = 0,u = q.front();q.pop();
        pair<int,int> pr;
        for(vector<int>::iterator pt = g[u].begin();pt < g[u].end();++ pt)
            if(dis[u] == dis[*pt] + 1)
                tof = *pt;
        printf("node %d\n",u);
        sort(t[u].begin(),t[u].end());
        for(vector<pair<int,int> >::iterator pt = t[u].begin();pt < t[u].end();++ pt){
            printf("read %d a\n",(*pt).second);
            printf("write a %d\n",tof);
            t[tof].push_back(make_pair((*pt).first+1,u));
        }
        if(tof)
            q.push(tof);
    }
    return;
}
int main(void){
    freopen("oldcomputer4.in","r",stdin);
    freopen("oldcomputer4.out","w",stdout);
    solve();
    return 0;
}//7
