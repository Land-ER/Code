#include "testlib.h"
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <queue>
#include <cctype>
#include <string>
#include <cstdlib>
#include <map>
#include <iostream>
using namespace std;
//Initialization
const int OverallTestNumber = 10;
int A1,A2,A3;
vector<string> EmptyVector;
map<string,int> Argc;
int LoopIndex;
int DataID;
int NodeNumber;
int LineNumber;
int CodeLength;
bool Connection[1010][1010];
pair<bool,int> SendCommandInfo[1010][1010];
bool used[1010];
int F[45]={0,1}; 
map<int,int> Task4Answer; 
void Error(const char * str){
	quitf(_wa,str);
}
void InitArgc(){
	Argc["mov"]=2;Argc["add"]=2;Argc["dec"]=2;Argc["mul"]=2;
	Argc["div"]=2;Argc["and"]=2;Argc["or"]=2;Argc["xor"]=2;
	Argc["jmp"]=1;Argc["jz"]=2;Argc["jnz"]=2;Argc["jgz"]=2;
	Argc["jsz"]=2;Argc["read"]=2;Argc["write"]=2;Argc["node"]=1;
}
//Basic Functions
bool checkNum(const char * str){
	int u=0;
	while(str[u]=='+' || str[u]=='-')	++u;
	if(!isdigit(str[u]))	return false;
	while(isdigit(str[u]))	++u;
	if(str[u]!='\0' && str[u]!=EOF)	return false;
	return true;
}
int getNum(const char * str){
	int ret=0,flag=1;
	int u=0;
	while(str[u]=='+' || str[u]=='-'){
		if(str[u]=='-')	flag*=-1;
		++u;
	}
	while(isdigit(str[u])){
		ret=ret*10+str[u]-'0';
		++u;
	}
	return ret*flag;
}
//Structure
struct Statement{
	string type;
	vector<string> argv;
	Statement(string type="")
		:type(type){argv.clear();}
};
vector<Statement> EmptyVector2;
struct Computer{
	int ID;
	int StatementIndex;
	int CommandLength;
	int inputIndex;
	int a,b;
	vector<Statement> Command;
	vector<int> ExpectedOutput;
	vector<int> OutputList;
	vector<int> InputList;
	Computer(int ID=0,vector<Statement> Command=EmptyVector2):ID(ID),Command(Command){
		OutputList.clear();
		InputList.clear();
		inputIndex=0;
		StatementIndex=0;
		CommandLength=Command.size();
		ExpectedOutput.clear();
		a=b=0;
	}
	void goForward(){
		++StatementIndex;
		if(StatementIndex==CommandLength)
			StatementIndex=0;
	}
	Statement currentStatement(){
		if(CommandLength==0)
			return Statement("");
		return Command[StatementIndex];
	}
	bool haveInput(){
		return inputIndex!=(int)InputList.size();
	}
	int input(){
		return InputList[inputIndex++];
	}
	bool checkAnswer(){
		int l1=OutputList.size();
		int l2=ExpectedOutput.size();
		if(l1!=l2)	return false;
		for(int i=0;i<l1;i++)
			if(OutputList[i]!=ExpectedOutput[i])
				return false;
		return true;
	}
}comp[1010];
void readCodeInfo(){
	int CurrentComputer=0;
	vector<Statement> cmd;
	cmd.clear();string str;
	while(!ouf.eof()){
		str = ouf.readToken();
		if(str=="node"){
			str = ouf.readToken();
			if(!checkNum(str.c_str()))
				Error("Node number error");
			int U=getNum(str.c_str());
			if(U<1 || U>NodeNumber)
				Error("Node number error");
			comp[CurrentComputer]=Computer(CurrentComputer,cmd);
			CurrentComputer=U;cmd.clear();
		}
		else if(Argc[str]){
			Statement curr(str);int id=Argc[str];
			for(int i=0;i<id;i++){
				str = ouf.readToken();
				if(str!="a" && str!="b" && !checkNum(str.c_str()))
					Error(("Unknown command parameter: "+str).c_str());
				curr.argv.push_back(str);
			}
			cmd.push_back(curr);
		}
		else
			Error(("Unknown command: "+str).c_str());
		++CodeLength;
		if(CodeLength>1000000)
			Error("Code too long");
		ouf.readEoln();
	}
	comp[CurrentComputer]=Computer(CurrentComputer,cmd);
	return ;
}
int getStringVal(string str,int id){
	if(str=="a")	return comp[id].a;
	if(str=="b")	return comp[id].b;
	if(checkNum(str.c_str()))	return getNum(str.c_str());
	Error(("Cannot know the meaning of "+str).c_str());
	return 0;
}
int & getStringAdd(string str,int id){
	if(str=="a")	return comp[id].a;
	if(str=="b")	return comp[id].b;
	Error(("Cannot find the index of "+str).c_str());
	return *(new int());
}
void runSingleStatement(Statement stat,int id){
	if(stat.type=="mov")	getStringAdd(stat.argv[0],id)=getStringVal(stat.argv[1],id);
	else if(stat.type=="add")	getStringAdd(stat.argv[0],id)+=getStringVal(stat.argv[1],id);
	else if(stat.type=="dec")	getStringAdd(stat.argv[0],id)-=getStringVal(stat.argv[1],id);
	else if(stat.type=="mul")	getStringAdd(stat.argv[0],id)*=getStringVal(stat.argv[1],id);
	else if(stat.type=="div")	getStringAdd(stat.argv[0],id)/=getStringVal(stat.argv[1],id);
	else if(stat.type=="and")	getStringAdd(stat.argv[0],id)&=getStringVal(stat.argv[1],id);
	else if(stat.type=="or")	getStringAdd(stat.argv[0],id)|=getStringVal(stat.argv[1],id);
	else if(stat.type=="xor")	getStringAdd(stat.argv[0],id)^=getStringVal(stat.argv[1],id);
	else if(stat.type=="jmp"){
		int TL=getStringVal(stat.argv[0],id);
		if(TL<1 || TL>comp[id].CommandLength)
			Error("Jump out of range");
		comp[id].StatementIndex=TL-1;
		return ;
	}
	else if(stat.type=="jz"){
		if(getStringAdd(stat.argv[0],id)!=0){
			comp[id].goForward();
			return ;
		}
		int TL=getStringVal(stat.argv[1],id);
		if(TL<1 || TL>comp[id].CommandLength)
			Error("Jump out of range");
		comp[id].StatementIndex=TL-1;
		return ;
	}
	else if(stat.type=="jnz"){
		if(getStringAdd(stat.argv[0],id)==0){
			comp[id].goForward();
			return ;
		}
		int TL=getStringVal(stat.argv[1],id);
		if(TL<1 || TL>comp[id].CommandLength)
			Error("Jump out of range");
		comp[id].StatementIndex=TL-1;
		return ;
	}
	else if(stat.type=="jgz"){
		if(getStringAdd(stat.argv[0],id)<=0){
			comp[id].goForward();
			return ;
		}
		int TL=getStringVal(stat.argv[1],id);
		if(TL<1 || TL>comp[id].CommandLength)
			Error("Jump out of range");
		comp[id].StatementIndex=TL-1;
		return ;
	}
	else if(stat.type=="jsz"){
		if(getStringAdd(stat.argv[0],id)>=0){
			comp[id].goForward();
			return ;
		}
		int TL=getStringVal(stat.argv[1],id);
		if(TL<1 || TL>comp[id].CommandLength)
			Error("Jump out of range");
		comp[id].StatementIndex=TL-1;
		return ;
	}
	else
		Error(("Unknown command: "+stat.type).c_str());
	comp[id].goForward();
}
bool checkResult4(){
	map<int,int> cpy=Task4Answer;int U=50;
	for(int i=1;i<=NodeNumber;i++){
		for(int j=comp[i].OutputList.size()-1;j>=0;j--){
			int P=comp[i].OutputList[j];
			--cpy[P];
			if(cpy[P]<0)
				return false;
			--U;
		}
	}
	if(U)	return false;
	return true;
}
bool checkResult(){
	if(DataID==4)	return checkResult4();
	for(int i=1;i<=NodeNumber;i++)
		if(!comp[i].checkAnswer())	return false;
	return true;
}
int runCode(){
	for(int IDX=1;IDX<=A3;IDX++){
		memset(used,0,sizeof(used));
		for(int curr=1;curr<=NodeNumber;curr++)
			if(comp[curr].currentStatement().type=="write"){
				used[curr]=true;
				Statement stat=comp[curr].currentStatement();
				int To=0;
				if(!checkNum(stat.argv[1].c_str()))
					Error("Command error: write");
				To=getNum(stat.argv[1].c_str());
				if(To<0 || To>NodeNumber)
					Error("Command error: write");
				int info=getStringVal(stat.argv[0],curr);
				if(To==0){
					comp[curr].OutputList.push_back(info);
					comp[curr].goForward();
				}
				else if(!Connection[curr][To])
					Error("No connection");
				else if(!SendCommandInfo[curr][To].first){
					SendCommandInfo[curr][To]=make_pair(true,info);
					comp[curr].goForward();
				}
			}
		for(int curr=1;curr<=NodeNumber;curr++)
			if(comp[curr].currentStatement().type=="read" && !used[curr]){
				used[curr]=true;
				Statement stat=comp[curr].currentStatement();
				int From=0;
				if(!checkNum(stat.argv[0].c_str()))
					Error("Command error: read");
				From=getNum(stat.argv[0].c_str());
				if(From<0 || From>NodeNumber)
					Error("Command error: read");
				if(From==0){
					int Y;
					if(!comp[curr].haveInput())	continue;
					Y=comp[curr].input();
					getStringAdd(stat.argv[1],curr)=Y;
					comp[curr].goForward();
				}
				else if(!Connection[From][curr])
					Error("No connection");
				else if(SendCommandInfo[From][curr].first){
					int Y=SendCommandInfo[From][curr].second;
					SendCommandInfo[From][curr]=make_pair(false,0);
					getStringAdd(stat.argv[1],curr)=Y;
					comp[curr].goForward();
				}
			}
		for(int curr=1;curr<=NodeNumber;curr++)
			if(comp[curr].currentStatement().type!="write"
			&& comp[curr].currentStatement().type!="read"
			&& comp[curr].currentStatement().type!=""
			&& !used[curr])
				runSingleStatement(comp[curr].currentStatement(),curr);
		if(checkResult())
			return IDX;
	}
	return A3+1;
}
inline int randomInt(){
	return ((rnd.next(0,(1<<16)-1)<<16)+rnd.next(0,(1<<16)-1));
}
inline int randomNonNeg(){
	return ((rnd.next(0,(1<<15)-1)<<16)+rnd.next(0,(1<<16)-1));
}
void makeTask1(bool largest){
	int A=randomInt();
	comp[1].InputList.push_back(A);
	comp[1].ExpectedOutput.push_back(A);
}
void makeTask2(bool largest){
	int A=rnd.next(0,44);
	if(largest)	A=44;
	comp[1].InputList.push_back(A);
	comp[1].ExpectedOutput.push_back(F[A]);
}
void makeTask3(bool largest){
	int A=rnd.next(1,100);
	if(largest)	A=100;
	for(int i=1;i<=A;i++){
		int B=randomInt();
		comp[1].InputList.push_back(B);
		comp[100].ExpectedOutput.push_back(B);
	}
}
void makeTask4(bool largest){
	for(int i=1;i<=50;i++){
		int A=randomInt();
		comp[i].InputList.push_back(A);
		++Task4Answer[A];
	}
}
void makeTask5(bool largest){
	for(int i=1;i<=10;i++){
		int A=randomInt();
		comp[i].InputList.push_back(A);
		comp[101-i].ExpectedOutput.push_back(A);
	}
}
void makeTastInfo(int testid){
	if(testid==OverallTestNumber){
		if(DataID==1)	makeTask1(true);
		if(DataID==2)	makeTask2(true);
		if(DataID==3)	makeTask3(true);
		if(DataID==4)	makeTask4(true);
		if(DataID==5)	makeTask5(true);
	}
	else{
		if(DataID==1)	makeTask1(false);
		if(DataID==2)	makeTask2(false);
		if(DataID==3)	makeTask3(false);
		if(DataID==4)	makeTask4(false);
		if(DataID==5)	makeTask5(false);
	}
}
void cleanInfo(){
	for(int i=1;i<=NodeNumber;i++){
		comp[i].OutputList.clear();
		comp[i].InputList.clear();
		comp[i].inputIndex=0;
		comp[i].StatementIndex=0;
		comp[i].a=comp[i].b=0;
		comp[i].ExpectedOutput.clear();
	}
	for(int i=1;i<=NodeNumber;i++)
		for(int j=1;j<=NodeNumber;j++)
			SendCommandInfo[i][j]=make_pair(false,0);
	Task4Answer.clear();
}
int main(int argc,char ** argv){
	registerTestlibCmd(argc,argv);
	InitArgc();
	for(int i=2;i<=44;i++)
		F[i]=F[i-1]+F[i-2];
	DataID = inf.readInt();
	NodeNumber = inf.readInt();
	LineNumber = inf.readInt();
	for(int i=0,a,b;i<LineNumber;i++){
		a = inf.readInt();
		b = inf.readInt();
		Connection[a][b]=Connection[b][a]=true;
	}
	readCodeInfo();
	int res=0;
	if(DataID==1)	A1=200,A2=300,A3=10000;
	if(DataID==2)	A1=4,A2=5,A3=50;
	if(DataID==3)	A1=211,A2=422,A3=5000;
	if(DataID==4)	A1=7,A2=12,A3=200;
	if(DataID==5)	A1=21,A2=22,A3=31;
	for(int Tester=1;Tester<=OverallTestNumber;Tester++){
		makeTastInfo(Tester);
		res=max(res,runCode());
		cleanInfo();
	}
	if(res>A3)
		quitf(_wa,"Run more than %d times to get the answer: too long!",A3);
	if(res>A2)
		quitp(0.3,"Run at most %d times to get the answer: too long!",res);
	if(res>A1)
		quitp(0.6,"Run at most %d times to get the answer: too long!",res);
	quitf(_ok,"Run at most %d times to get the answer: that\'s enough!",res);
}