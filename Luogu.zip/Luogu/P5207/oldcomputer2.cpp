#include<cstdio>
void solve(void){
    long long int f[50];
    int i,j;
    f[0] = 0;f[1] = 1;
    for(i = 1;f[i-1] <= 1000000000;f[i] = f[i-1] + f[i-2]) ++ i;
    printf("node 1\n");
    printf("read 0 a\n");
    printf("add a 4\n");
    printf("jmp a\n");
    for(j = 0;j < i;++ j){
        printf("write %lld 0\n",f[j]);
    }
    return;
}
int main(void){
    freopen("oldcomputer2.in","r",stdin);
    freopen("oldcomputer2.out","w",stdout);
    solve();
    return 0;
}
