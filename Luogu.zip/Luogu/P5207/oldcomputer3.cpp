#include<cstdio>
#include<iostream>
#include<queue>
#include<vector>
#include<stack>
#include<cstring>
#include<algorithm>
using namespace std;
vector<int> graph[105];//100 120
int dis[105],pre[105];bool vis[105];
void input(void){
    int u,v,n;
    cin >> u >> v >> n;
    for(int i = 0;i < 120;++ i){
        cin >> u >> v;
        graph[u].push_back(v);
        graph[v].push_back(u);
    }
    return;
}
void spfa(void){
    queue<int> q;
    memset(dis,0x3f,sizeof(dis));
    dis[1] = 0;
    q.push(1);
    while(!q.empty()){
        int u = q.front();q.pop();
        for(vector<int>::iterator pt = graph[u].begin();pt < graph[u].end();++ pt){
            if(dis[*pt] > dis[u] + 1){
                pre[*pt] = u;
                dis[*pt] = dis[u] + 1;
                if(!vis[*pt]){
                    vis[*pt] = 1;
                    q.push(*pt);
                }
            }
        }
    }
    return;
}
void solve(void){
	input();
	spfa();
    int i = 100;
    pre[1] = 0;
    int last = 0;
    while(i != 0){
        printf("node %d\n",i);
        printf("read %d a\n",pre[i]);
        printf("write a %d\n",last);
        last = i;
        i = pre[i];
    }
    return;
}
int main(void){
    freopen("oldcomputer3.in","r",stdin);
    freopen("oldcomputer3.out","w",stdout);
    solve();
    return 0;
}//211
