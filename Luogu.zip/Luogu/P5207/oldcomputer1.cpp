#include<cstdio>
void solve(void){
    printf("node 1\n");
    printf("read 0 a\n");
    printf("write a 0\n");
}
int main(void){
    freopen("oldcomputer1.in","r",stdin);
    freopen("oldcomputer1.out","w",stdout);
    solve();
    return 0;
}