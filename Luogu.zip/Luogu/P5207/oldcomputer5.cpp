#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;//100 180
vector<int> g[105];
vector<pair<int,pair<int,int> > > m[105];
int dis[12][105],pre[12][105];
bool vis[105][30],inq[105];
void input(void){
    int u,v;
    scanf("%d%d%d",&u,&u,&v);
    for(int i = 0;i < 180;++ i){
        scanf("%d%d",&u,&v);
        g[u].push_back(v);
        g[v].push_back(u);
    }
    return;
}
void spfa(int s){
    int e = 101 - s;
    queue<int> q;
    dis[s][s] = 0;
    q.push(s);
    while(!q.empty()){
        int u = q.front(),v;inq[u] = 0;q.pop();
        for(auto pt = g[u].begin();pt < g[u].end();++ pt){
            v = *pt;
            int t = dis[s][u] + 1;
            while(vis[u][t] || vis[v][t+1])
                ++ t;
            if(dis[s][v] > t){
                dis[s][v] = t;
                pre[s][v] = u;
                if(!inq[v]){
                    q.push(v);
                    inq[v] = 1;
                }
            }
        }
    }
    int nxt = 0;
    while(e){
        m[e].push_back(make_pair(dis[s][e],make_pair(pre[s][e],nxt)));
        vis[e][dis[s][e]] = 1;
        if(pre[s][e])
			vis[pre[s][e]][dis[s][pre[s][e]]] = 1;
        nxt = e;
        e = pre[s][e];
    }
    return;
}
void solve(void){
	input();
    memset(dis,0x3f,sizeof(dis));
    for(int i = 1;i < 10;++ i)
        spfa(i);
    for(int i = 1;i <= 100;++ i){
        if(m[i].empty())
            continue;
        sort(m[i].begin(),m[i].end());
        printf("node %d\n",i);
        for(auto pt = m[i].begin();pt < m[i].end();++ pt){
            printf("read %d a\n",((*pt).second).first);
            printf("write a %d\n",((*pt).second).second);
        }
    }
    return;
}
int main(void){
    freopen("oldcomputer5.in","r",stdin);
    freopen("oldcomputer5.out","w",stdout);
    solve();
    return 0;
}//21
