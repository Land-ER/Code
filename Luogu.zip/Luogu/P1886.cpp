#include<bits/stdc++.h>
class monotonic_queue{
    private:
        int q[1000005],head,tail,cnt[1000005],v;
        bool (*func)(int a,int b);
    public:
        void init(int x,bool (*f)(int a,int b));
        int top(void);
        void pop(void);
        void push(int x);
}q;
void monotonic_queue::init(int x,bool (*f)(int a,int b)){
    head = 0,tail = 0;
    v = x;
    func = f;
    for(int i = 0;i < 1000000;++ i)
        q[i] = x,cnt[i] = 0;
    return;
}
int monotonic_queue::top(void){
    return q[head];
}
void monotonic_queue::pop(void){
    if(cnt[head])
        -- cnt[head];
    else
        q[head] = v,++ head;
    return;
}
void monotonic_queue::push(int x){
    int c = 0;
    while(!func(q[(tail-1+1000000) % 1000000],x))
        tail = (tail-1+1000000) % 1000000,c = c + cnt[tail] + 1;
    q[tail] = x,cnt[tail] = c,++ tail;
    return;
}
bool cmp1(int a,int b){
    return a < b;
}
bool cmp2(int a,int b){
    return a > b;
}
int n,k,a[1000005];
int main(void){
    scanf("%d%d",&n,&k);
    for(int i = 0;i < n;++ i)
        scanf("%d",&a[i]);
    q.init(-2147483648,cmp1);
    for(int i = 0;i < k-1;++ i)
        q.push(a[i]);
    for(int i = k-1;i < n;++ i){
        q.push(a[i]);
        printf("%d ",q.top());
        q.pop();
    }
    printf("\n");
    q.init(2147483647,cmp2);
    for(int i = 0;i < k-1;++ i)
        q.push(a[i]);
    for(int i = k-1;i < n;++ i){
        q.push(a[i]);
        printf("%d ",q.top());
        q.pop();
    }
    return 0;
}
