#include<bits/stdc++.h>

class Debugger{

    private:
        std::ofstream filestream;

    public:
        void init(char object[]);
        Debugger(void);
        ~Debugger(void);

        template<typename T> void print(T object);
        template<typename T1,typename T2> void print(std::pair<T1,T2> object);
        template<typename T> void print(std::vector<T> object);
        void say(char object[]);

        template<typename T> Debugger operator<<(const T object);
        template<typename T> Debugger operator<<(const std::vector<T> object);
        Debugger operator<<(char object[]);

}debugger;

void Debugger::init(char object[]){
    filestream.open(object,std::ios::out);
    return;
}

Debugger::Debugger(void){
    return;
}

Debugger::~Debugger(void){
    filestream.close();
    return;
}

template<typename T> void Debugger::print(T object){
    filestream << T << ' ';
    return;
}

template<typename T1,typename T2> void Debugger::print(std::pair<T1,T2> object){
    filestream << object.first << ',' << object.second << ' ';
    return;
}

template<typename T> void Debugger::print(std::vector<T> object){
    for(auto pt = object.begin();pt != object.end();++ pt)
        filestream << *pt << ' ';
    return;
}

void Debugger::say(char object[]){
    filestream << object << ' ';
    return;
}

template<typename T> Debugger Debugger::operator<<(const T object){
    print(object);
    return *this;
}

template<typename T> Debugger Debugger::operator<<(const std::vector<T> object){
    print(object);
    return *this;
}