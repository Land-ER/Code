#include<iostream>
#include<cstring>
using namespace std;
int main(void){//192 327
	bool f[10];
	int a,b,c;
	int x,y,z;
	int i;
	for(i = 192;i <= 327;++ i){
		memset(f,0,sizeof(f));
		a = i;
		b = a * 2;
		c = a * 3;
		x = a;
		y = b;
		z = c;
		for( ;a > 0;a /= 10){
			if(!(a%10))
				goto flag;
			else if(f[a%10])
				goto flag;
			else
				f[a%10] = 1;
		}
		for( ;b > 0;b /= 10){
			if(!(b%10))
				goto flag;
			else if(f[b%10])
				goto flag;
			else
				f[b%10] = 1;
		}
		for( ;c > 0;c /= 10){
			if(!(c%10))
				goto flag;
			else if(f[c%10])
				goto flag;
			else
				f[c%10] = 1;
		}
		cout << x << ' ' << y << ' ' << z << '\n';
		flag:continue;
	}
	return 0;
}
