#include<bits/stdc++.h>
using namespace std;
int main(void){
    int n,a[105];
    cin >> n;
    for(int i = 1;i <= n;++ i)
        cin >> a[i];
    sort(a+1,a+n+1);
    int p = unique(a+1,a+n+1) - (a+1);
    cout << p << '\n';
    for(int i = 1;i <= p;++ i)
        cout << a[i] << ' ';
    return 0;
}