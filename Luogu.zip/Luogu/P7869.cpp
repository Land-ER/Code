#include<iostream>
#include<string>
using namespace std;
string input;
int make(void)
{
    for(int i = 0;i < 100001;++ i)
    {
        if(input[i] == '\\')
        {
            if(input[i+1] == 'n')
                return 1;
            else if(input[i+1] == 'r')
            {
                if(input[i+2] == '\\' && input[i+3] == 'n')
                    return 0;
                else return 2;
            }
        }
    }
}
int main(void){
    getline(cin,input);
    int num = make();
    if(!num)
        cout << "windows";
    else if(!(num-1))
        cout << "linux";
    else 
        cout << "mac";
    return 0;
}