#include<bits/stdc++.h>
using namespace std;
int t,n,Q,ret;
int main(void){
    stack<int> s;
    vector<int> q;
    bool flag;
    scanf("%d",&t);
    while(t--){
        while(!s.empty()) s.pop();
        q.clear();
        flag = 1;
        scanf("%d%d",&n,&Q);
        s.push(0);
        for(int i = 1;i < n;++ i){
            if(!s.empty()){
                printf("%d %d\n",s.top(),i);
                fflush(stdout);
                scanf("%d",&ret);
                if(ret){
                    if(flag){
                        q.push_back(s.top());
                        q.push_back(i);
                    }
                    else{
                        q.push_back(i);
                        q.push_back(s.top());
                    }
                    s.pop();
                }
                else
                    s.push(i);
            }
            else{
                printf("%d %d\n",*(q.rbegin()),i);
                fflush(stdout);
                scanf("%d",&ret);
                if(!ret)
                    flag = !flag;
                s.push(i);
            }
        }
        if(s.empty()){
            printf("%d\n",n);
            for(int i = 0;i < (int)q.size();++ i)
                printf("%d ",q[i]);
            printf("\n");
            fflush(stdout);
        }
        else{
            int l = 1,r = 0;
            for(auto pt = q.begin();pt < q.end();++ pt){
                printf("%d %d\n",*pt,s.top());
                fflush(stdout);
                scanf("%d",&r);
                if(l && r){
                    q.insert(pt,s.top());
                    s.pop();
                    break;
                }
                l = r;
            }
            if(s.empty()){
                printf("%d\n",n);
                for(int i = 0;i < (int)q.size();++ i)
                    printf("%d ",q[i]);
                printf("\n");
                fflush(stdout);
            }
            else{
                printf("%d\n",-1);
                fflush(stdout);
            }
        }
    }
    return 0;
}