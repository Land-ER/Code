#include<bits/stdc++.h>
long long int a[100005],d[400025],mul[400025],add[400025];
int n,m,p;
#define lc (id<<1)
#define rc ((id<<1)+1)
#define mid ((l+r)>>1)
#define mem (r-l+1)
#define lmem (((l+r)>>1)-l+1)
#define rmem (r-((l+r)>>1))
void build(int id,int l,int r){
    mul[id] = 1;
    if(l == r)
        d[id] = a[l];
    else{
        build(lc,l,mid);
        build(rc,mid+1,r);
        d[id] = (d[lc] + d[rc]) % p;
    }
    return;
}
void pushdown(int id,int l,int r){
    if(l == mid)
        d[lc] = (d[lc] * mul[id] + add[id]) % p;
    else
        d[lc] = (d[lc] * mul[id] + add[id] * lmem) % p,add[lc] = (add[lc] * mul[id] + add[id]) % p,mul[lc] = (mul[lc] * mul[id]) % p;
    if(r == mid+1)
        d[rc] = (d[rc] * mul[id] + add[id]) % p;
    else
        d[rc] = (d[rc] * mul[id] + add[id] * rmem) % p,add[rc] = (add[rc] * mul[id] + add[id]) % p,mul[rc] = (mul[rc] * mul[id]) % p;
    add[id] = 0,mul[id] = 1;
    return;
}
void modify_add(int id,int l,int r,int s,int e,int op){
    if(l == r)
        d[id] = (d[id] + op) % p;
    else{
        if(s <= l && e >= r)
            d[id] = (d[id] + (mem*op) % p) % p,add[id] = (add[id] + op) % p;
        else{
            pushdown(id,l,r);
            if(s <= mid)
                modify_add(lc,l,mid,s,e,op);
            if(e > mid)
                modify_add(rc,mid+1,r,s,e,op);
            d[id] = (d[lc] + d[rc]) % p;
        }
    }
    return;
}
void modify_mul(int id,int l,int r,int s,int e,int op){
    if(l == r)
        d[id] = (d[id] * op) % p;
    else{
        if(s <= l && e >= r)
            d[id] = (d[id] * op) % p,add[id] = (add[id] * op) % p,mul[id] = (mul[id] * op) % p;
        else{
            pushdown(id,l,r);
            if(s <= mid)
                modify_mul(lc,l,mid,s,e,op);
            if(e > mid)
                modify_mul(rc,mid+1,r,s,e,op);
            d[id] = (d[lc] + d[rc]) % p;
        }
    }
    return;
}
long long int query(int id,int l,int r,int s,int e){
    long long int sum = 0;
    if(s <= l && e >= r)
        sum += d[id];
    else{
        pushdown(id,l,r);
        if(s <= mid)
            sum = (sum + query(lc,l,mid,s,e)) % p;
        if(e > mid)
            sum = (sum + query(rc,mid+1,r,s,e)) % p;
    }
    return sum;
}
#undef lc
#undef rc
#undef mid
#undef mem
#undef lmem
#undef rmem
int main(void){
    int opt,x,y,k;
    scanf("%d%d%d",&n,&m,&p);
    for(int i = 1;i <= n;++ i)
        scanf("%lld",&a[i]);
    build(1,1,n);
    for(int i = 1;i <= m;++ i){
        scanf("%d%d%d",&opt,&x,&y);
        if(opt == 1){
            scanf("%d",&k);
            modify_mul(1,1,n,x,y,k);
        }
        else if(opt == 2){
            scanf("%d",&k);
            modify_add(1,1,n,x,y,k);
        }
        else if(opt == 3){
            printf("%lld\n",query(1,1,n,x,y));
        }
    }
    return 0;
}
