#include<iostream>
using namespace std;
int main(void){
	int n,i,j,k = 1;
	bool f[30];
	int ret[30];
	cin >> n;
	if(n%2)
		cout << -1;
	else{
		for(i = 0;n > 1;++ i){
			f[i] = n%2;
			n /= 2;
		}
		f[i] = n;
		for(j = 0;j <= i;++ j){
			ret[j] = f[j] * k;
			k *= 2;
		}
		for(-- j;j >= 0;-- j)
			if(ret[j])
				cout << ret[j] << ' ';
	}
	return 0;
}
