#include<cstdio>
int main(void){
	long long int a,n,in,ret,base,p;
	scanf("%lld%lld%lld",&a,&in,&p);
	n = in;
	base = a;
	ret = n&1 ? base : 1;
	n >>= 1;
	while(n){
		base = base * base % p;
		if(n&1)
			ret = ret * base % p;
		n >>= 1;
	}
	ret %= p;
	printf("%lld^%lld mod %lld=%lld",a,in,p,ret);
	return 0;
}
