#include<iostream>
using namespace std;
struct T{
	int l,r;
};
T list[500005];
int list_len = 0;
inline long long int sum(int l,int r){
	long long int ret = 1ll * (l+r) * (r-l+1) / 2;
	return ret;
}
void push(int l,int r){
	list[list_len].l = l;
	list[list_len].r = r;
	++ list_len;
	return;
}
long long int pop(long long int k){
	long long int ret;
	int i = list_len - 1;
	int len = list[i].r - list[i].l + 1;
	if(k < len){
		ret = sum(list[i].r-k+1,list[i].r);
		list[i].r -= k;
		return ret;
	}
	else{
		ret = sum(list[i].l,list[i].r);
		k -= len;
		-- list_len;
		ret += pop(k);
		return ret;
	}
}
void make(void){
	int n,op,l,r;
	long long int ret,k;
	cin >> n;
	for(int i = 0;i < n;++ i)
	{
		cin >> op;
		if(op == 1){
			cin >> l >> r;
			push(l,r);
		}
		else{
			cin >> k;
			ret = pop(k);
			cout << ret << '\n';
		}
	}
	return;
}
int main(void){
	make();
	return 0;
}
