#include<bits/stdc++.h>
int n,m,a[200005],d[200005];
struct node{
    int l,r,value,lc,rc;
    node(void){
        value = lc = rc = 0;
        return;
    }
    int mid(void){
        return (l+r) / 2;
    }
};
class rope{
    private:
        node tree[5000005];
        int length,root[200005],tot,rt;
        int build(int l,int r);
        int add(int n,int k);
    public:
        rope(void);
        void init(int len);
        void modify(int k);
        int query(int l,int r,int k);
}t;
rope::rope(void){
    tot = rt = 0;
    return;
}
int rope::build(int l,int r){
    int now = tot++;
    tree[now].l = l,tree[now].r = r;
    if(l != r){
        tree[now].lc = build(tree[now].l,tree[now].mid());
        tree[now].rc = build(tree[now].mid()+1,tree[now].r);
    }
    return now;
}
int rope::add(int n,int k){
    int now = tot++;
    tree[now].value = tree[n].value + 1;
    tree[now].l = tree[n].l,tree[now].r = tree[n].r;
    if(tree[now].l == tree[now].r)
        return now;
    if(k <= tree[now].mid()){
        tree[now].lc = add(tree[n].lc,k);
        tree[now].rc = tree[n].rc;
    }else{
        tree[now].lc = tree[n].lc;
        tree[now].rc = add(tree[n].rc,k);
    }
    return now;
}
void rope::init(int len){
    length = len;
    root[rt++] = build(1,length);
    return;
}
void rope::modify(int k){
    root[rt] = add(root[rt-1],k);
    ++ rt;
    return;
}
int rope::query(int l,int r,int k){
    int t1 = root[l-1],t2 = root[r];
    while(tree[t1].l != tree[t1].r){
        if(tree[tree[t2].lc].value - tree[tree[t1].lc].value >= k){
            t1 = tree[t1].lc;
            t2 = tree[t2].lc;
        }else{
            k -= tree[tree[t2].lc].value - tree[tree[t1].lc].value;
            t1 = tree[t1].rc;
            t2 = tree[t2].rc;
        }
    }
    return tree[t1].l;
}
std::unordered_map<int,int> mp,pm;
void init(void){
    int b;
    std::sort(a+1,a+n+1);
    b = std::unique(a+1,a+n+1) - a - 1;
    for(int i = 1;i <= b;++ i)
        mp.insert(std::make_pair(i,a[i])),pm.insert(std::make_pair(a[i],i));
    t.init(b);
    return;
}
int main(void){
    scanf("%d%d",&n,&m);
    for(int i = 1;i <= n;++ i)
        scanf("%d",&a[i]),d[i] = a[i];
    init();
    for(int i = 1;i <= n;++ i)
        t.modify(pm[d[i]]);
    while(m--){
        int l,r,k,ret;
        scanf("%d%d%d",&l,&r,&k);
        ret = t.query(l,r,k);
        printf("%d\n",mp[ret]);
    }
}
