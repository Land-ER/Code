#include<bits/stdc++.h>
int n,a[100005],k;

int main(void){

}