#include<bits/stdc++.h>
using namespace std;
class Function{
    private:
        double a,b,c,d;
    public:
        void init(double x1,double x2,double x3,double x4);
        double f(double x);
}fun;
void Function::init(double x1,double x2,double x3,double x4){
    a = x1,b = x2,c = x3,d = x4;
    return;
}
double Function::f(double x){
    return a*x*x*x + b*x*x + c*x + d;
}

int main(void){
    queue<pair<double,double> > q;
    priority_queue<double,vector<double>,greater<double> > p;
    double l,r,m;
    double a,b,c,d;
    scanf("%lf%lf%lf%lf",&a,&b,&c,&d);
    fun.init(a,b,c,d);
    q.push(make_pair(-100.0,100.0));
    while(p.size() < 3){
        pair<double,double> pr = q.front();
        q.pop();
        l = pr.first,r = pr.second,m = (l+r) / 2.0;
        double fl = fun.f(l),fm = fun.f(m),fr = fun.f(r);
        if(r-l < 0.005){
            p.push(m);
            continue;
        }
        if(fl == 0)
            p.push(l);
        if(fm == 0)
            p.push(m);
        if(fr == 0)
            p.push(r);
        if(fl*fm < 0)
            q.push(make_pair(l,m));
        if(fm*fr < 0)
            q.push(make_pair(m,r));
    }
    printf("%.2f",p.top());p.pop();
    printf("%.2f",p.top());p.pop();
    printf("%.2f",p.top());p.pop();
    return 0;
}