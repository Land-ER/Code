#include<cstdio>
int n,m,k,r;
int a[12],b[12],c[12];
inline int max(int a,int b){
	return a>b ? a : b;
}
void input(void){
	scanf("%d%d%d%d",&n,&m,&k,&r);
	for(int i = 0;i < n;++ i)
		scanf("%d",&a[i]);
	for(int i = 0;i < m;++ i)
		scanf("%d",&b[i]);
	for(int i = 0;i < m;++ i)
		scanf("%d",&c[i]);
	return;
}
void solve1(void){
	int dp[155] = {0};
	int i,j;
	for(i = 0;i < m;++ i)
		for(j = r;j >= b[i];-- j)
			dp[j] = max(dp[j],dp[j-b[i]]+c[i]);
	for(i = 0;dp[i] < k;++ i);
	r -= i;
	return;
}
void solve2(void){
	int dp[155] = {0};
	int i,j;
	for(i = 0;i < n;++ i)
		for(j = r;j >= a[i];-- j)
			dp[j] = max(dp[j],dp[j-a[i]]+1);
	printf("%d",dp[r]);
	return;
}
int main(void){
	input();
	solve1();
	solve2();
	return 0;
}
