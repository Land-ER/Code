#include<iostream>
#define MAXM 10001
#define MAXT 10000001
using namespace std;
int t,m;
int a[MAXM],b[MAXM];
long long int dp[MAXT];
inline int max(int a,int b){
	return a>b ? a : b;
}
void input(void){
	cin >> t >> m;
	for(int i = 0;i < m;++ i)
		cin >> a[i] >> b[i];
	return;
}
void make(void){
	int i,j;
	dp[0] = 0;
	for(i = 0;i < m;++ i)
		for(j = a[i];j <= t;++ j)
			dp[j] = max(dp[j],dp[j-a[i]]+b[i]);
	cout << dp[t];
	return;
}
int main(void){
	input();
	make();
	return 0;
}
