#include<bits/stdc++.h>
struct edge{
    int u,v,w;
    bool operator<(const edge &_)const{
        return w<_.w;
    }
}g[200005];
int n,m,x,y,z;
int f[5005],r[5005],c[5005];
void init(void){
    scanf("%d%d",&n,&m);
    for(int i = 0;i < m;++ i){
        scanf("%d%d%d",&x,&y,&z);
        g[i].u = x,g[i].v = y,g[i].w = z;
    }
    for(int i = 0;i <= n;++ i)
        f[i] = i,c[i] = 1;
    return;
}
int find(int x){
    while(f[x] != x)
        x = f[x];
    return x;
}
bool merge(int a,int b){
    int fa = find(a),fb = find(b);
    if(fa == fb)
        return 0;
    if(r[fa] < r[fb])
        f[fa] = fb,c[fb] += c[fa];
    else
        f[fb] = fa,c[fa] += c[fb];
    r[fa] += r[fa] == r[fb];
    return 1;
}
void kruskal(void){
    int ans = 0,cnt = 0;
    std::sort(g,g+m);
    for(int i = 0;i < m;++ i){
        if(merge(g[i].u,g[i].v))
            ans += g[i].w,++ cnt;
        if(cnt == n-1)
            break;
    }
    if(c[find(1)] == n)
        printf("%d",ans);
    else
        printf("orz");
    return;
}
int main(void){
    init();
    kruskal();
    return 0;
}
