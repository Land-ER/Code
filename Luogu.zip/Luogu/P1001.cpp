#include<bits/stdc++.h>
using namespace std;
int main(void){
    int a,b;
    cin >> a >> b;
    while(b--)
        a++;
    cout << a;
    return 0;
}