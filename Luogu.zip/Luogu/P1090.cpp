#include<bits/stdc++.h>
using namespace std;
priority_queue<int,vector<int>,greater<int> > q;
int main(void){
	int a,b,i,n,ans = 0;
	scanf("%d",&n);
	while(n--){
		scanf("%d",&i);
		q.push(i);
	}
	while(q.size() > 1){
		a = q.top();
		q.pop();
		b = q.top();
		q.pop();
		ans += a + b;
		q.push(a+b);
	}
	printf("%d",ans);
	return 0;
}
