#include<bits/stdc++.h>
int n,m,a[500050],d[500050];
#define lb (x & -x)
void build(void){
    for(int x = 1;x <= n;++ x){
        d[x] += a[x];
        if(x+lb <= n)
            d[x+lb] += d[x];
    }
    return;
}
void modify(int x,int c){
    while(x <= n){
        d[x] += c;
        x += lb;
    }
    return;
}
int query(int x){
    int ret = 0;
    while(x >= 1){
        ret += d[x];
        x -= lb;
    }
    return ret;
}
#undef lb
int main(void){
    int l = 0,t,x,y,k;
    scanf("%d%d",&n,&m);
    for(int i = 1;i <= n;++ i){
        scanf("%d",&t);
        a[i] = t - l;
        l = t;
    }
    build();
    for(int i = 1;i <= m;++ i){
        scanf("%d%d",&t,&x);
        if(t == 1){
            scanf("%d%d",&y,&k);
            modify(x,k);
            modify(y+1,-k);
        }
        else
            printf("%d\n",query(x));
    }
    return 0;
}
