#include<iostream>
#define ll long long
int n,m;
int a[1002][1002];
ll int dp[2][1000][4] = {-9223372036854775805};
inline ll int max(int a,int b){
	return a>b ? a : b;
}
inline ll int max(int a,int b,int c){
	return max(max(a,b),c);
}
void input(void){
	int i,j;
	std::cin >> n >> m;
	for(i = 1;i < m;++ i)
		for(j = 1;j < n;++ j)
			std::cin >> a[i][j];
	return;
}
void solve(void){
	ll int i,j,k,c,d,sum;
	for(j = 1;j <= n;++ j)
		dp[0][j][0] = dp[0][j-1][0] + a[0][j];
	for(i = 2;i <= m;++ i)
		for(j = 1;j <= n;++ j){
			c = j % 2;//��ǰд�� 
			d = c ^ 1;
			sum = a[i][j];
			for(k = j-1;k > 0;--k){
				sum += a[i][k];
				dp[c][j][1] = max(sum+dp[d][j][0],dp[c][j][1]);
			}
			sum = a[i][j];
			for(k = j+1;k <= n;++ k){
				sum += a[i][k];
				dp[c][j][2] = max(sum+dp[d][j][0],dp[c][j][2]);
			}
			dp[c][j][3] = a[i][j] + dp[d][j][0];
			dp[c][j][0] = max(dp[c][j][1],dp[c][j][2],dp[c][j][3]);
		}
	std::cout << dp[c][j][0];
	return;
}
int main(void){
	input();
	solve();
	return 0;
}
