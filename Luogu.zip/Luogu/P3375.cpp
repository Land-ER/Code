#include<bits/stdc++.h>
char s1[1000005],s2[1000005];
int kmp[1000005],l1,l2;
int main(void){
    scanf("%s%s",s1+1,s2+1);
    l1 = strlen(s1+1),l2 = strlen(s2+1);
    int i,j;
    for(i = 2;i <= l2;++ i){
        j = kmp[i-1];
        while(s2[j+1] != s2[i] && j)
            j = kmp[j];
        kmp[i] = j + (s2[j+1]==s2[i]);
    }
    for(i = 1,j = 0;i <= l1;++ i){
        while(s1[i] != s2[j+1] && j)
            j = kmp[j];
        if(s1[i] == s2[j+1])
            ++ j;
        if(j == l2){
            printf("%d\n",i-l2+1);
            j = kmp[j];
        }
    }
    for(int k = 1;k <= l2;++ k)
        printf("%d ",kmp[k]);
    return 0;
}
