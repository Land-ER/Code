#include<cstdio>
int main(void){
    int n,a,b;
    scanf("%d%d",&n,&a);
    while(-- n){
        scanf("%d",&b);
        a ^= b;
    }
    printf("%d",a);
    return 0;
}