#include<iostream>
#include<string>
#include<stack>
#define ll long long
using namespace std;
ll int abs(ll int a){
	return a>0 ? a : -a;
}
stack<ll int> s;
bool error;
ll int a,b;
inline void checkempty(){
	if(s.empty()) 
		error = 1;
	return;
}
inline void checksize(){
	if(s.size() < 2)
		error = 1;
	return;
}
inline void checkabs(int x){
	if(abs(x) > 1000000000)
		error = 1;
	return;
}
void NUM(ll int x){
	checkabs(x);
	if(!error)
		s.push(x);
	return;
}
void POP(void){
	checkempty();
	if(!error)
		s.pop();
	return;
}
void INV(void){
	checkempty();
	if(!error){
		a = s.top();
		s.pop();
		s.push(-a);
	}
	return;
}
void DUP(void){
	checkempty();
	if(!error)
		s.push(s.top());
	return;
}
void SWP(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		s.push(a);
		s.push(b);
	}
	return;
}
void ADD(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		checkabs(a+b);
		if(!error)
			s.push(a+b);
	}
	return;
}
void SUB(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		checkabs(b-a);
		if(!error)
			s.push(b-a);
	}
	return;
}
void MUL(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		checkabs(a*b);
		if(!error)
			s.push(a*b);
	}
	return;
}
void DIV(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		if(a == 0)
			error = 1;
		else
			s.push(b/a);
	}
	return;
}
void MOD(void){
	checksize();
	if(!error){
		a = s.top();
		s.pop();
		b = s.top();
		s.pop();
		if(a == 0)
			error = 1;
		else
			s.push(b%a);
	}
	return;
}
void END(void){
	if(s.size() == 1)
		cout << s.top() << '\n';
	else
		cout << "ERROR\n";
	return;
}
struct node{
	string c;
	ll int num;
}f[2005];int len;
ll int x[2005];int n;
void read(void){
	for(len = 0; ;++ len){
		cin >> f[len].c;
		if(f[len].c == "END"){
			++ len;
			break;
		}
		if(f[len].c == "NUM")
			cin >> f[len].num;
	}
	cin >> n;
	for(int i = 0;i < n;++ i)
		cin >> x[i];
	return;
}
void function(ll int x){
	NUM(x);
	for(int i = 0;i < len;++ i){
		if(f[i].c == "NUM")
			NUM(f[i].num);
		else if(f[i].c == "POP")
			POP();
		else if(f[i].c == "INV")
			INV();
		else if(f[i].c == "DUP")
			DUP();
		else if(f[i].c == "SWP")
			SWP();
		else if(f[i].c == "ADD")
			ADD();
		else if(f[i].c == "SUB")
			SUB();
		else if(f[i].c == "MUL")
			MUL();
		else if(f[i].c == "DIV")
			DIV();
		else if(f[i].c == "MOD")
			MOD();
		else if(f[i].c == "END")
			END();
		if(error){
			cout << "ERROR\n";
			error = 0;
			break;
		}
	}
	while(!s.empty())
		s.pop();
	return;
}
int main(void){
	read();
	for(int i = 0;i < n;++ i)
		function(x[i]);
	return 0;
}
