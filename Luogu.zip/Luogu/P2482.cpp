#include<bits/stdc++.h>
#define DEBUG
using namespace std;
char statu[12],tos[12];
int n,m,cnt1,cnt2,health[12],pt;
bool weapon[12],k[12];
vector<char> card[12];
vector<char> heap;
#ifdef DEBUG
ofstream debugger;
#endif
int nxt(int x){
	do{
		x = x+1<=n ? x+1 : 1;
	}while(tos[x] == 'D');
    return x;
}
void init(void){
    #ifdef DEBUG
    debugger << "FUNCTION INIT CALLED.\n" << flush;
    #endif
    cin >> n >> m;
    char s[2];
    for(int i = 1;i <= n;++ i){
    	health[i] = 4;
        char x1,x2,x3,x4;
        cin >> s >> x1 >> x2 >> x3 >> x4;
        card[i].push_back(x1);
        card[i].push_back(x2);
        card[i].push_back(x3);
        card[i].push_back(x4);
        statu[i] = s[0],tos[i] = 'N';
        if(statu[i] == 'F')
            ++ cnt2;
        else
            ++ cnt1;
        if(statu[i] == 'M')
            pt = i,tos[i] = 'M';
    }
    char x;
    for(int i = 0;i < m;++ i)
        cin >> x,heap.push_back(x);
    return;
}
void getcard(int id,int amount){
    #ifdef DEBUG
    debugger << "FUNCTION GETCARD CALLED,parameter" << ":id=" << id << ",amount=" << amount << ".\n" << flush;
    #endif
    while(amount --){
        card[id].push_back(heap[0]);
        if(heap.size() > 1)
            heap.erase(heap.begin());
    }
    return;
}
int decide(int a,int b){
    #ifdef DEBUG
    debugger << "FUNCTION DECIDE CALLED,parameter" << ":a=" << a << ",b=" << b << ".\n" << flush;
    #endif
    switch(statu[a]){
        case 'M':
            switch(tos[b]){
                case 'N':
                    return 0;
                case 'P':
                case 'F':
                    return 1;
                case 'Z':
                    return 2;
            }
        case 'Z':
            switch(tos[b]){
                case 'N':
                case 'P':
                    return 0;
                case 'F':
                    return 1;
                case 'M':
                case 'Z':
                    return 2;
            }
        case 'F':
            switch(tos[b]){
                case 'N':
                case 'P':
                    return 0;
                case 'M':
                case 'Z':
                    return 1;
                case 'F':
                    return 2;
            }
    }
    return 0;
}
void make(int event,int a,int b){
    #ifdef DEBUG
    debugger << "FUNCTION MAKE CALLED,parameter" << ":event=" << event << ",a=" << a << ",b=" << b << ".\n" << flush;
    #endif
    if((tos[a] != 'N' && tos[a] != 'P') || (tos[b] == 'N' || tos[b] == 'P'))
        return;
    if(event == 0 && tos[b] == 'M'){
        tos[a] = 'P';
    }
    else if(event == 1){
        if(tos[b] == 'F')
            tos[a] = 'Z';
        else
            tos[a] = 'F';
    }
    else{
        if(tos[b] == 'F')
            tos[a] = 'F';
        else
            tos[a] = 'Z';
    }
    return;
}
void dead(int a,int b){
    #ifdef DEBUG
    debugger << "FUNCTION DEAD CALLED,parameter" << ":a=" << a << ",b=" << b << ".\n" << flush;
    #endif
    if(statu[b] == 'M'){
        tos[b] = 'D';
        cnt1 = 0;
        return;
    }
    else if(statu[b] == 'F'){
        -- cnt2;
        if(!cnt2)
            return;
        tos[b] = 'D';
        getcard(a,3);
        return;
    }
    else if(statu[a] == 'M' && statu[b] == 'Z'){
        card[a].clear();
        -- cnt1;
        tos[b] = 'D';
        return;
    }
}
void check(int id,int p){
    #ifdef DEBUG
    debugger << "FUNCTION CHECK CALLED,parameter" << ":id=" << id << ",p=" << p << "." << flush;
    #endif
    vector<char>::iterator q;
    if(!health[id]){
        q = find(card[id].begin(),card[id].end(),'P');
        if(q != card[id].end()){
            ++ health[id];
            card[id].erase(q);
        }
        else
            dead(p,id);
    }
    return;
}
bool J(int id){
    #ifdef DEBUG
    debugger << "FUNCTION J CALLED,parameter" << ":id=" << id << ".\n" << flush;
    #endif
    vector<char>::iterator q;
    bool flag = 0;
    for(int t = nxt(id);t != id;t = nxt(t)){
        if(decide(t,id) != 2)
            continue;
        q = find(card[t].begin(),card[t].end(),'J');
        if(q != card[t].end()){
            card[t].erase(q);
            make(2,t,id);
            if(!J(t))
                flag = 1;
        }
    }
    return flag;
}
#ifdef DEBUG
void show(void){
	debugger << "HEAP:" << flush;for(auto pt = heap.begin();pt != heap.end();++ pt)debugger << *pt << flush;debugger << '\n' << flush;
    for(int i = 1;i <= n;++ i){
        debugger << "PLAYER " << i << flush;
        debugger << ":health=" << health[i] << flush;
        debugger << ",statu=" << statu[i] << flush;
        debugger << ",tos=" << tos[i] << flush;
        debugger << ",card=";for(auto pt = card[i].begin();pt != card[i].end();++ pt)debugger << *pt << flush;
        debugger << ",weapon=" << weapon[i] << flush;
        debugger << ",k=" << k[i] << flush;
        debugger << '\n' << flush;
    }
    return;
}
#endif
#define next nxt(pt)
void game(void){
    #ifdef DEBUG
    debugger << "FUNCTION GAME CALLED.\n" << flush;
    #endif
    pt = 1;
    int t;
    while(cnt1 > 0 && cnt2 > 0){
        #ifdef DEBUG
        show();
        debugger << endl;
        debugger << "TURNED PLAYER " << pt << ".\n" << flush;
        #endif
        k[pt] = 0;
        getcard(pt,2);
        #ifdef DEBUG
        show();
        #endif
        vector<char>::iterator p = card[pt].begin(),q;
        bool flag;
        while(p != card[pt].end()){
            switch(*p){
                case 'P':
                    if(health[pt] < 4){
                        #ifdef DEBUG
                        debugger << "CASE P.\n" << flush;
                        #endif
                        ++ health[pt];
                        card[pt].erase(p);
                        p = card[pt].begin();
                    }else
                    	++ p;
                    break;
                case 'K':
                    if(k[pt] && !(weapon[pt]))
                        break;
                    k[pt] = 1;
                    if(decide(pt,next) == 1){
                        #ifdef DEBUG
                        debugger << "CASE K:" << next << "\n" << flush;
                        #endif
                        make(1,pt,next);
                        q = find(card[next].begin(),card[next].end(),'D');
                        card[pt].erase(p);
                        if(q != card[next].end()){
                            card[next].erase(q);
                        }
                        else{
                            -- health[next];
                            check(next,pt);
                        }
                        p = card[pt].begin();
                        #ifdef DEBUG
                        debugger << "\n" << flush;
                        #endif
                    }else
                    	++ p;
                    break;
                case 'F':
                    flag = 0;
                    for(t = next;t != pt;t = nxt(t)){
                        if(decide(pt,t) == 1){
                            flag = 1;
                            break;
                        }
                    }
                    if(flag){
                        #ifdef DEBUG
                        debugger << "CASE F:" << t << "\n" << flush;
                        #endif
                        card[pt].erase(p);
                        make(1,pt,t);
                        if(J(t))
                            break;
                        int now = t,e = pt;
                        while(true){
                            q = find(card[now].begin(),card[now].end(),'K');
                            if(q == card[now].end()){
                                -- health[now];
                                check(now,e);
                                break;
                            }
                            #ifdef DEBUG
                            debugger << "k" << flush;
                            #endif
                            card[now].erase(q);
                            swap(now,e);
                        }
                        #ifdef DEBUG
                        debugger << '\n' << flush;
                        #endif
                        p = card[pt].begin();
                    }else
                    	++ p;
                    break;
                case 'N':
                    #ifdef DEBUG
                    debugger << "CASE N:\n" << flush;
                    #endif
                    card[pt].erase(p);
                    for(t = next;t != pt;t = nxt(t)){
                        if(J(t))
                            continue;
                        q = find(card[t].begin(),card[t].end(),'K');
                        if(q == card[t].end()){
                            make(0,pt,t);
                            -- health[t];
                            check(t,pt);
                            if(cnt1 == 0 || cnt2 == 0)
                                break;
                        }else
                            card[t].erase(q);
                        #ifdef DEBUG
                        debugger << "\n" << flush;
                        #endif
                    }
                    p = card[pt].begin();
                    break;
                case 'W':
                    #ifdef DEBUG
                    debugger << "CASE W:\n" << flush;
                    #endif
                    card[pt].erase(p);
                    for(t = next;t != pt;t = nxt(t)){
                        #ifdef DEBUG
                        debugger << t << flush;
                        #endif
                        if(J(t))
                            continue;
                        q = find(card[t].begin(),card[t].end(),'D');
                        if(q == card[t].end()){
                            make(0,pt,t);
                            -- health[t];
                            check(t,pt);
                            if(cnt1 == 0 || cnt2 == 0)
                                break;
                        }else
                            card[t].erase(q);
                        #ifdef DEBUG
                        debugger << "\n" << flush;
                        #endif
                    }
                    p = card[pt].begin();
                    break;
                case 'Z':
                #ifdef DEBUG
                debugger << "CASE Z.\n" << flush;
                #endif
                    card[pt].erase(p);
                    weapon[pt] = 1;
                    p = card[pt].begin();
                    break;
                default:
                    ++ p;
            }
            if(cnt1 == 0 || cnt2 == 0)
                break;
        }
        pt = next;
    }
    return;
}
void result(void){
    #ifdef DEBUG
    debugger << "FUNCTION RESULT CALLED.\n" << flush;
    show();
    #endif
    if(cnt1)
        cout << "MP\n";
    else
        cout << "FP\n";
    vector<char>::iterator p;
    for(int i = 1;i <= n;++ i){
        if(tos[i] == 'D')
            cout << "DEAD\n";
        else{
            for(p = card[i].begin();p != card[i].end();++ p)
                cout << *p << ' ';
            cout << '\n';
        }
    }
    return;
}
int main(void){
    #ifdef DEBUG
    freopen("P2482.in","r",stdin);
    debugger.open("P2482.txt",ios::out);
    #endif
    init();
    game();
    result();
    return 0;
}
