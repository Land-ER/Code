#include<iostream>
#include<string>
using namespace std;
struct command{
	string op;
	string num0,num1,num2;
};
int R[5],E[5],Flag,Val,Ret,Line,sAddr[512000];
string stack;
void read(void){
	int _lenth,_lenth_count;
	cin >> _lenth;
	for(_lenth_count = 0;_lenth_count < _lenth;++ _lenth_count){
		getline(cin,stack);
		
	}
}
