#include<iostream>
int main(void){
	char a[8];
	int i,j = 0;
	std::cin >> a;
	for(i = 0;i < 8;++ i)
		if(a[i] == '1')
			++ j;
	std::cout << j;
	return 0;
}
